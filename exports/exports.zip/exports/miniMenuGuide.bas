Attribute VB_Name = "miniMenuGuide"
' =============================================================================
' HOW TO BUILD YOUR OWN MENUS
' =============================================================================
'
' This module uses TWO custom classes:
'
'   1. clsContextMenu
'   2. clsMenuItem
'
' The clsContextMenu class handles:
'   - Creating the CommandBar
'   - Showing the popup menu
'   - Routing clicks
'
' The clsMenuItem class represents:
'   - Buttons
'   - Popup menus
'   - Nested child items
'
'
' =============================================================================
' BASIC CONCEPT
' =============================================================================
'
' Think of the menu like a TREE:
'
' MAIN MENU
' +-- Button
' +-- Button
' +-- Popup
' �   +-- Child Button
' �   +-- Child Button
' �   +-- Popup
' �       +-- Another Child
' +-- Button
'
'
' =============================================================================
' STEP 1 - CREATE A MENU OBJECT
' =============================================================================
'
' Always start by creating a clsContextMenu object.
'
' -----------------------------------------------------------------
'
' Dim menu As clsContextMenu
' Set menu = New clsContextMenu
'
' menu.MenuName = "MyMenuName"
'
' -----------------------------------------------------------------
'
' IMPORTANT:
'
' MenuName MUST be unique.
'
' If you reuse the same name, the old menu may still exist unless
' deleted first.
'
'
' =============================================================================
' STEP 2 - ADD TOP LEVEL BUTTONS
' =============================================================================
'
' Use:
'
' menu.AddButton
'
'
' -----------------------------------------------------------------
' SYNTAX
' -----------------------------------------------------------------
'
' menu.AddButton _
'       Caption, _
'       ActionValue, _
'       FaceID, _
'       BeginGroup, _
'       Enabled, _
'       Checked, _
'       Tooltip, _
'       ShortcutText
'
'
' -----------------------------------------------------------------
' EXAMPLE
' -----------------------------------------------------------------
'
' menu.AddButton _
'       "Open Notepad", _
'       "OPEN_NOTEPAD", _
'       252, _
'       False, _
'       True, _
'       False, _
'       "Launches Windows Notepad", _
'       "Ctrl+N"
'
'
' -----------------------------------------------------------------
' PARAMETER EXPLANATION
' -----------------------------------------------------------------
'
' Caption
'   The visible text shown on the menu.
'
' ActionValue
'   A UNIQUE routing key.
'   This gets sent into MenuRouter().
'
' FaceID
'   Office built-in icon number.
'
' BeginGroup
'   Adds a separator line ABOVE this item.
'
' Enabled
'   True  = clickable
'   False = grayed out
'
' Checked
'   Adds a checkmark beside the item.
'
' Tooltip
'   Hover text.
'
' ShortcutText
'   Fake shortcut text shown on the right side.
'
'
' =============================================================================
' STEP 3 - CREATE A POPUP / SUBMENU
' =============================================================================
'
' Use:
'
' menu.AddPopup
'
'
' -----------------------------------------------------------------
' EXAMPLE
' -----------------------------------------------------------------
'
' Dim tools As clsMenuItem
'
' Set tools = menu.AddPopup("Tools")
'
'
' This creates:
'
' Tools >
'
'
' =============================================================================
' STEP 4 - ADD CHILD ITEMS TO A POPUP
' =============================================================================
'
' Use:
'
' AddChild parentMenu, caption, action, faceid
'
'
' -----------------------------------------------------------------
' EXAMPLE
' -----------------------------------------------------------------
'
' AddChild tools, "Calculator", "OPEN_CALC", 283
'
' AddChild tools, "Paint", "OPEN_PAINT", 344
'
'
' RESULT:
'
' Tools >
'     Calculator
'     Paint
'
'
' =============================================================================
' STEP 5 - CREATE NESTED POPUPS
' =============================================================================
'
' You can create menus INSIDE menus.
'
'
' -----------------------------------------------------------------
' EXAMPLE
' -----------------------------------------------------------------
'
' Dim admin As clsMenuItem
'
' Set admin = AddPopupChild(tools, "Admin")
'
' AddChild admin, "User Manager", "USERS", 487
' AddChild admin, "Permissions", "PERMS", 642
'
'
' RESULT:
'
' Tools >
'     Admin >
'         User Manager
'         Permissions
'
'
' =============================================================================
' STEP 6 - SHOW THE MENU
' =============================================================================
'
' ALWAYS finish with:
'
' menu.Show
'
'
' -----------------------------------------------------------------
' EXAMPLE
' -----------------------------------------------------------------
'
' menu.Show
'
'
' =============================================================================
' STEP 7 - HANDLE BUTTON CLICKS
' =============================================================================
'
' ALL clicks go into:
'
' MenuRouter(ByVal ActionValue As String)
'
'
' -----------------------------------------------------------------
' EXAMPLE
' -----------------------------------------------------------------
'
' Case "OPEN_CALC"
'     Shell "calc.exe", vbNormalFocus
'
'
' If the menu item ActionValue is:
'
'     "OPEN_CALC"
'
' then THAT Case will fire.
'
'
' =============================================================================
' COMPLETE SIMPLE EXAMPLE
' =============================================================================
'
' Public Sub MyFirstMenu()
'
'     Dim menu As clsContextMenu
'     Set menu = New clsContextMenu
'
'     menu.MenuName = "MyFirstMenu"
'
'     menu.AddButton "Say Hello", "HELLO", 59
'
'     Dim tools As clsMenuItem
'     Set tools = menu.AddPopup("Tools")
'
'     AddChild tools, "Calculator", "OPEN_CALC", 283
'     AddChild tools, "Notepad", "OPEN_NOTEPAD", 252
'
'     menu.Show
'
' End Sub
'
'
' Then in MenuRouter:
'
'
' Case "HELLO"
'     MsgBox "Hello world!"
'
' Case "OPEN_CALC"
'     Shell "calc.exe", vbNormalFocus
'
' Case "OPEN_NOTEPAD"
'     Shell "notepad.exe", vbNormalFocus
'
'
' =============================================================================
' HOW TO FIND FACEID ICONS
' =============================================================================
'
' FaceIDs are built-in Office icons.
'
' Example IDs:
'
'   59     = Home
'   252    = Notepad-ish icon
'   283    = Calculator
'   487    = Information
'   463    = Warning
'   330    = Critical
'   23     = Folder
'
'
' You can search online for:
'
'   "Excel VBA FaceID list"
'
' or build a FaceID browser tool.
'
'
' =============================================================================
' BEGINGROUP EXAMPLE
' =============================================================================
'
' This adds a separator line ABOVE the item:
'
' AddChild tools, _
'          "Dangerous Action", _
'          "DELETE_ALL", _
'          1085, _
'          True
'
'
' RESULT:
'
' ------------------------
' Dangerous Action
'
'
' =============================================================================
' CHECKED ITEM EXAMPLE
' =============================================================================
'
' AddChild tools, _
'          "Dark Mode", _
'          "DARKMODE", _
'          1088, _
'          False, _
'          True, _
'          True
'
'
' The last TRUE means:
'
'     Checked = True
'
'
' =============================================================================
' DISABLED ITEM EXAMPLE
' =============================================================================
'
' AddChild tools, _
'          "Premium Feature", _
'          "PREMIUM", _
'          1087, _
'          False, _
'          False
'
'
' Enabled = False
'
' This makes the item grayed out.
'
'
' =============================================================================
