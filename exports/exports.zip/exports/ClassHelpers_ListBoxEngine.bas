Attribute VB_Name = "ClassHelpers_ListBoxEngine"
Option Explicit

' ============================================================
'   Core ListBox helpers for CSVEngine
'   - Bind 2D array to ListBox
'   - Bind CSVEngine (all columns / subset)
'   - Auto-size column widths
'   - Sort ListBox by column
' ============================================================
Public Type FieldBinding
    columnName As String
    control As Object
End Type

' ============================================================
' Binds a CSVEngine row to a set of controls
' mapping is a 2-column array:
'   mapping(i,0) = CSV column name
'   mapping(i,1) = control object (TextBox or Label)
' ============================================================
Public Sub BindRowToControls(csv As CSVEngine, Key As String, mapping As Variant)
    Dim rowArr As Variant
    Dim fb As CSVFieldBinding
    Dim i As Long
    Dim idx As Long

    If Len(Key) = 0 Then Exit Sub

    rowArr = csv.GetRowArray(Key)
    If IsEmpty(rowArr) Then Exit Sub

    For i = LBound(mapping) To UBound(mapping)
        Set fb = mapping(i)

        If Not fb.control Is Nothing Then
            idx = csv.headerIndex(fb.columnName)
            If idx >= 0 Then
                fb.control.Value = rowArr(idx)
            Else
                fb.control.Value = ""
            End If
        End If
    Next i
End Sub

'=============================================================
' Binds a CSVEngine row into any UserForm automatically
' If a control has .Tag = the column name, it gets filled.
' Works with TextBoxes, ComboBoxes, Labels, etc.
'=============================================================
Public Sub BindRowToForm(frm As Object, csv As CSVEngine, rowKey As String)
    Dim rowArr As Variant
    Dim ctrl As Object
    Dim colName As String
    Dim idx As Long

    If Len(rowKey) = 0 Then Exit Sub

    rowArr = csv.GetRowArray(rowKey)
    If IsEmpty(rowArr) Then Exit Sub

    For Each ctrl In frm.Controls
        colName = Trim$(CStr(ctrl.tag))

        If colName <> "" Then
            idx = csv.headerIndex(colName)

            If idx >= 0 Then
                '--- Assign value depending on control type ---
                On Error Resume Next
                Select Case True
                    Case TypeOf ctrl Is MSForms.TextBox
                        ctrl.Value = rowArr(idx)

                    Case TypeOf ctrl Is MSForms.ComboBox
                        ctrl.Value = rowArr(idx)

                    Case TypeOf ctrl Is MSForms.label
                        ctrl.Caption = rowArr(idx)
                    Case TypeOf ctrl Is MSForms.CheckBox
                        ctrl.Value = rowArr(idx)
                    Case Else
                        ' Unhandled control type - ignore safely
                End Select
                On Error GoTo 0
            End If
        End If
    Next ctrl
End Sub
' ---------------------------
' Bind a 2D array to a ListBox
' ---------------------------
Public Sub LB_BindArray(lb As MSForms.ListBox, data As Variant, Optional clearFirst As Boolean = True)
    Dim rows As Long, cols As Long
    Dim r As Long, c As Long
    
    If clearFirst Then lb.Clear
    
    On Error GoTo SafeExit
    rows = UBound(data, 1)
    cols = UBound(data, 2)
    
    ' Format numeric columns to 2 decimal places
    For r = LBound(data, 1) To UBound(data, 1)
        For c = LBound(data, 2) To UBound(data, 2)
            If IsNumeric(data(r, c)) And Not IsEmpty(data(r, c)) Then
                ' Only format decimal numbers (not integers)
                If InStr(1, CStr(data(r, c)), ".") > 0 Then
                    data(r, c) = Format(data(r, c), "0.00")
                End If
            End If
        Next c
    Next r
    
    lb.ColumnCount = cols
    lb.List = data
SafeExit:
End Sub
' ---------------------------
' Bind entire CSV (all columns) to ListBox
' ---------------------------
Public Sub LB_BindCSV_All(lb As MSForms.ListBox, csv As CSVEngine)
    Dim data As Variant
    data = csv.To2DArray
    LB_BindArray lb, data
End Sub

' ---------------------------
' Bind CSV subset of columns (by header name)
' Example: Array("LOC","HOLD_REAS_T","HOLD_USER_ID")
' ---------------------------
Public Sub LB_BindCSV_Subset(lb As MSForms.ListBox, csv As CSVEngine, cols As Variant, Optional keys As Collection = Nothing, Optional decimalMax As Long = 2)
    Dim result() As Variant
    Dim rowArr As Variant
    Dim r As Long, c As Long, i As Long
    Dim colIndex As Long
    Dim fieldCount As Long
    Dim k As Variant
    Dim val As Variant
    
    ' If keys provided but empty, clear and exit
    If Not keys Is Nothing Then
        If keys.Count = 0 Then
            lb.Clear
            Exit Sub
        End If
    End If
    
    fieldCount = UBound(cols) - LBound(cols) + 1
    
    ' Determine row count and source
    If keys Is Nothing Then
        ' Get all rows from csv.To2DSubset
        result = csv.To2DSubset(cols)
    Else
        ' Filter by keys
        ReDim result(1 To keys.Count, 1 To fieldCount)
        
        r = 1
        For Each k In keys
            rowArr = csv.GetRowArray(CStr(k))
            
            If Not IsEmpty(rowArr) Then
                c = 1
                For i = LBound(cols) To UBound(cols)
                    colIndex = csv.headerIndex(CStr(cols(i)))
                    If colIndex >= 0 Then
                        result(r, c) = rowArr(colIndex)
                    Else
                        result(r, c) = ""
                    End If
                    c = c + 1
                Next i
                r = r + 1
            End If
        Next k
        
        ' Trim if needed
        If r > 1 And r - 1 <> UBound(result, 1) Then
            ReDim Preserve result(1 To r - 1, 1 To fieldCount)
        End If
    End If
    
    ' Apply decimal rounding to all numeric values in result
    For r = LBound(result, 1) To UBound(result, 1)
        For c = LBound(result, 2) To UBound(result, 2)
            val = result(r, c)
            If IsNumeric(val) And Not IsEmpty(val) And val <> "" Then
                result(r, c) = Round(CDbl(val), decimalMax)
            End If
        Next c
    Next r
    
    lb.ColumnCount = fieldCount
    lb.List = result
End Sub

' ============================================================
'   Auto-size ListBox columns based on content length
'   NOTE: This is heuristic, but good enough visually.
' ============================================================
Public Sub LB_AutoSizeColumns(lb As MSForms.ListBox, Optional maxRowsToScan As Long = 200)
    Dim r As Long, c As Long
    Dim rMax As Long, cMax As Long
    Dim maxLen() As Long
    Dim s As String
    Dim widths As String
    Dim cellValue As Variant
    
    If lb.ListCount = 0 Or lb.ColumnCount = 0 Then Exit Sub
    
    cMax = lb.ColumnCount
    rMax = lb.ListCount
    If rMax > maxRowsToScan Then rMax = maxRowsToScan
    
    ReDim maxLen(1 To cMax)
    
    ' Scan visible data
    For r = 0 To rMax - 1
        For c = 0 To cMax - 1
            cellValue = lb.List(r, c)
            
            ' Handle Null, Empty, and other edge cases
            If IsNull(cellValue) Then
                s = ""
            ElseIf IsEmpty(cellValue) Then
                s = ""
            Else
                s = CStr(cellValue)
            End If
            
            If Len(s) > maxLen(c + 1) Then
                maxLen(c + 1) = Len(s)
            End If
        Next c
    Next r
    
    ' Build ColumnWidths string (points)
    ' Approx: 1 char � 7 points, plus padding
    For c = 1 To cMax
        widths = widths & (maxLen(c) * 7 + 14) & ";"
    Next c
    
    lb.ColumnWidths = widths
End Sub

' ============================================================
'   Sort ListBox by a column
'   - Copies .List to 2D array
'   - Sorts array
'   - Writes back to .List
' ============================================================
Public Sub LB_SortByColumn(lb As MSForms.ListBox, ByVal sortColumn As Long, Optional ascending As Boolean = True)
    Dim rCount As Long, cCount As Long
    Dim arr() As Variant
    Dim r As Long, c As Long
    Dim arr2() As Variant
    
    If lb.ListCount = 0 Then Exit Sub
    If sortColumn < 1 Or sortColumn > lb.ColumnCount Then Exit Sub
    
    rCount = lb.ListCount
    cCount = lb.ColumnCount
    
    ' Copy ListBox.List (0-based) into 1-based array
    ReDim arr(1 To rCount, 1 To cCount)
    
    For r = 0 To rCount - 1
        For c = 0 To cCount - 1
            arr(r + 1, c + 1) = lb.List(r, c)
        Next c
    Next r
    
    ' Sort arr in-place by sortColumn
    QuickSort2D arr, LBound(arr, 1), UBound(arr, 1), sortColumn, ascending
    
    ' Convert back to 0-based for ListBox.List
    ReDim arr2(0 To rCount - 1, 0 To cCount - 1)
    
    For r = 1 To rCount
        For c = 1 To cCount
            arr2(r - 1, c - 1) = arr(r, c)
        Next c
    Next r
    
    lb.List = arr2
End Sub

' ============================================================
'   QuickSort for 2D array by column
' ============================================================
Private Sub QuickSort2D(ByRef a() As Variant, ByVal lo As Long, ByVal hi As Long, ByVal col As Long, ByVal ascending As Boolean)
    Dim i As Long, j As Long
    Dim pivot As Variant
    Dim tmp As Variant
    Dim mid As Long
    Dim c As Long, colCount As Long
    
    If lo >= hi Then Exit Sub
    
    i = lo
    j = hi
    
    colCount = UBound(a, 2)
    mid = (lo + hi) \ 2
    pivot = a(mid, col)
    
    Do While i <= j
        If ascending Then
            Do While CompareValues(a(i, col), pivot) < 0
                i = i + 1
            Loop
            Do While CompareValues(a(j, col), pivot) > 0
                j = j - 1
            Loop
        Else
            Do While CompareValues(a(i, col), pivot) > 0
                i = i + 1
            Loop
            Do While CompareValues(a(j, col), pivot) < 0
                j = j - 1
            Loop
        End If
        
        If i <= j Then
            ' swap entire rows i and j
            For c = 1 To colCount
                tmp = a(i, c)
                a(i, c) = a(j, c)
                a(j, c) = tmp
            Next c
            i = i + 1
            j = j - 1
        End If
    Loop
    
    If lo < j Then QuickSort2D a, lo, j, col, ascending
    If i < hi Then QuickSort2D a, i, hi, col, ascending
End Sub

' ============================================================
'   CompareValues � numeric-aware compare
'   Returns -1, 0, 1
' ============================================================
Private Function CompareValues(v1 As Variant, v2 As Variant) As Long
    Dim s1 As String, s2 As String
    Dim n1 As Double, n2 As Double
    Dim isNum1 As Boolean, isNum2 As Boolean
    
    s1 = CStr(v1)
    s2 = CStr(v2)
    
    isNum1 = IsNumeric(s1)
    isNum2 = IsNumeric(s2)
    
    If isNum1 And isNum2 Then
        n1 = CDbl(s1)
        n2 = CDbl(s2)
        If n1 < n2 Then
            CompareValues = -1
        ElseIf n1 > n2 Then
            CompareValues = 1
        Else
            CompareValues = 0
        End If
    Else
        If s1 < s2 Then
            CompareValues = -1
        ElseIf s1 > s2 Then
            CompareValues = 1
        Else
            CompareValues = 0
        End If
    End If
End Function

' ============================================================
' Bind search results to a ListBox
' ============================================================
Public Sub LB_BindFiltered(lb As MSForms.ListBox, csv As CSVEngine, keys As Collection)
    Dim r As Long, c As Long
    Dim arrRow As Variant
    Dim tmp() As Variant
    Dim k As Variant   ' <-- important if Option Explicit is on
    
    If keys.Count = 0 Then
        lb.Clear
        Exit Sub
    End If
    
    ReDim tmp(1 To keys.Count, 1 To csv.headerCount)
    
    r = 1
    For Each k In keys
        arrRow = csv.GetRowArray(CStr(k))
        If Not IsEmpty(arrRow) Then
            For c = LBound(arrRow) To UBound(arrRow)
                tmp(r, c + 1) = arrRow(c)
            Next c
            r = r + 1
        End If
    Next k
    
    ' Trim in case some keys didn't resolve
    If r > 1 And r - 1 <> UBound(tmp, 1) Then
        ReDim Preserve tmp(1 To r - 1, 1 To csv.headerCount)
    End If
    
    lb.ColumnCount = csv.headerCount
    lb.List = tmp
End Sub
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
Sub Demo_AdvancedEngine()
    Dim csv As New CSVEngine
    Dim ok As Boolean
    Dim fp As String
    Dim t0 As Double, elapsed As Double
    
    fp = Environ$("USERPROFILE") & "\Downloads\HOLDS.csv"
    
    t0 = Timer
    ok = csv.LoadFromFile(fp, "LOC")
    elapsed = Timer - t0
    
    Debug.Print "Loaded:", ok, "Rows:", csv.rowCount, "in"; Format(elapsed, "0.000"); "sec"
    If Not ok Then Exit Sub
    
    Debug.Print "FilePath:", csv.filePath
    Debug.Print String(40, "-")
    
    ' 1) Distinct HOLD_REAS_T
    Debug.Print "Distinct HOLD_REAS_T values:"
    Dim reasons As Collection, v As Variant
    Set reasons = csv.GetDistinctValues("HOLD_REAS_T")
    For Each v In reasons
        Debug.Print "  "; v
    Next v
    Debug.Print String(40, "-")
    
    ' 2) CountBy HOLD_USER_ID
    Debug.Print "Count of holds per user (HOLD_USER_ID):"
    Dim byUser As Object, k As Variant
    Set byUser = csv.CountBy("HOLD_USER_ID")
    For Each k In byUser.keys
        Debug.Print "  "; k; " ?"; byUser(k)
    Next k
    Debug.Print String(40, "-")
    
    ' 3) WhereContainsAny demo: all rows where reason has I12 or L11
    Debug.Print "Rows where HOLD_REAS_T contains I12 OR L11:"
    Dim hits As Collection
    Set hits = csv.WhereContainsAny("HOLD_REAS_T", "I12", "L11")
    For Each k In hits
        Debug.Print "  LOC:"; k; _
                    " Reason:"; csv.GetField(CStr(k), "HOLD_REAS_T"); _
                    " User:"; csv.GetField(CStr(k), "HOLD_USER_ID")
    Next k
    Debug.Print String(40, "-")
    
    ' 4) Export full data pretty to a sheet
    Dim wsData As Worksheet
    Set wsData = ThisWorkbook.Sheets.Add
    wsData.name = "Holds_Data_Pretty"
    csv.ExportPrettyToSheet wsData
    
    ' 5) Export summary by reason to another sheet
    Dim wsSummary As Worksheet
    Set wsSummary = ThisWorkbook.Sheets.Add
    wsSummary.name = "Holds_By_Reason"
    csv.ExportPrettySummaryCountBy "HOLD_REAS_T", wsSummary
    
    Debug.Print "Advanced demo completed."
End Sub

Public Sub LB_BindFiltered_Subset(lb As MSForms.ListBox, csv As CSVEngine, keys As Collection, cols As Variant)
    Dim r As Variant, c As Long
    Dim rowArr As Variant
    Dim idxs() As Long
    Dim i As Long
    
    ' Build index list for selected columns
    ReDim idxs(LBound(cols) To UBound(cols))
    For i = LBound(cols) To UBound(cols)
        idxs(i) = csv.headerIndex(CStr(cols(i)))
    Next i
    
    lb.Clear
    lb.ColumnCount = UBound(cols) - LBound(cols) + 1
    
    ' Add rows
    For Each r In keys
        rowArr = csv.GetRowArray(CStr(r))
        
        Dim outArr() As Variant
        ReDim outArr(LBound(cols) To UBound(cols))
        
        For i = LBound(cols) To UBound(cols)
            outArr(i) = rowArr(idxs(i))
        Next i
        
        lb.AddItem outArr(0)
        For c = 1 To UBound(outArr)
            lb.List(lb.ListCount - 1, c) = outArr(c)
        Next c
    Next r
End Sub


