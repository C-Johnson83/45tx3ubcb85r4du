Attribute VB_Name = "modHelpers"

Public csv As CSVEngine
Public Const DB_PATH As String = "J:\Quality\Defect Tracker\Defect_Submission_Database.csv"
Public Const HTMLFILEPATH As String = "J:\zz_Access_Tools_Data\Developers\Versions\Defect Tracking\Data\t0556_defect_tracker.html"
Public Const the_version As String = "v1.0.1"
Public MINI As clsContextMenu

Public Function SHORTCUTPATH() As String: SHORTCUTPATH = Environ("USERPROFILE") & "\Desktop\Defect Tracker.lnk": End Function
Public Function LOCALFOLDER() As String: LOCALFOLDER = Environ("USERPROFILE") & "\Documents\Defect Tracker": End Function
Public Function LOCALPATH() As String: LOCALPATH = LOCALFOLDER & "\Defect_Tracker_Team_Member.xlsm": End Function
Public Function ICONPATH() As String: ICONPATH = "J:\zz_Access_Tools_Data\Developers\Versions\Defect Tracking\defect.ico" '\\t0556groupshare.dist.target.com\groupshare\public\zz_Access_Tools_Data\Developers\Versions\Defect Tracking\defect.ico": End Function

End Function
Public Function LOCALICONPATH() As String: LOCALICONPATH = LOCALFOLDER & "\defect.ico": End Function

'Public Function tmdbcsv() As String: tmdbcsv = "J:\zz_Access_Tools_Data\Audit_Tool_Data\Settings\TMDB.csv": End Function
Public Function tmdbcsv() As String: tmdbcsv = "J:\zz_Access_Tools_Data\Developers\Versions\Defect Tracking\Data\T556 TMDB.csv": End Function
Public Function ParseCSVLine(line As String) As String()
    ' Parse single CSV line into fields
    Dim fields() As String
    ReDim fields(100)
    
    Dim fieldCount As Long
    fieldCount = 0
    
    Dim currentField As String
    currentField = ""
    
    Dim inQuotes As Boolean
    inQuotes = False
    
    Dim i As Long
    i = 1
    
    Do While i <= Len(line)
        Dim char As String
        char = mid(line, i, 1)
        
        If char = """" Then
            If inQuotes Then
                If i < Len(line) And mid(line, i + 1, 1) = """" Then
                    currentField = currentField & """"
                    i = i + 2
                Else
                    inQuotes = False
                    i = i + 1
                End If
            Else
                inQuotes = True
                i = i + 1
            End If
        ElseIf char = "," And Not inQuotes Then
            fields(fieldCount) = currentField
            fieldCount = fieldCount + 1
            currentField = ""
            i = i + 1
        Else
            currentField = currentField & char
            i = i + 1
        End If
    Loop
    
    fields(fieldCount) = currentField
    fieldCount = fieldCount + 1
    
    ReDim Preserve fields(fieldCount - 1)
    ParseCSVLine = fields
End Function

Public Function IsLeader() As Boolean

    Const LEADER_FILE As String = _
        "J:\zz_Access_Tools_Data\Audit_Tool_Data\Settings\TMDB.csv"

    Dim fileNum As Integer
    Dim lineText As String
    Dim fields As Variant

    Dim currentUser As String
    Dim rowUser As String
    Dim permission As String

    'Default = no permission
    IsLeader = False

    currentUser = Trim$(Environ$("USERNAME"))

    If Len(currentUser) = 0 Then Exit Function

    '--------------------------------------------------
    ' Make sure permission file exists
    '--------------------------------------------------
    If Len(Dir$(LEADER_FILE)) = 0 Then Exit Function

    On Error GoTo CleanFail

    fileNum = FreeFile

    Open LEADER_FILE For Input As #fileNum

    '--------------------------------------------------
    ' Search TMDB
    '
    ' Column A = username      fields(0)
    ' Column C = permission    fields(2)
    '--------------------------------------------------
    Do While Not EOF(fileNum)

        Line Input #fileNum, lineText

        If Len(Trim$(lineText)) > 0 Then

            fields = Split(lineText, ",")

            'Need at least columns A, B and C
            If UBound(fields) >= 2 Then

                rowUser = Trim$(Replace(CStr(fields(0)), """", ""))
                permission = Trim$(Replace(CStr(fields(2)), """", ""))

                'Does column A match current Windows username?
                If StrComp( _
                    rowUser, _
                    currentUser, _
                    vbTextCompare) = 0 Then

                    'User found.
                    'Check column C for DC ADMIN.
                    If StrComp( _
                        permission, _
                        "DC ADMIN", _
                        vbTextCompare) = 0 Then

                        IsLeader = True

                    End If

                    'Username is unique, so we're done.
                    Exit Do

                End If

            End If

        End If

    Loop

    Close #fileNum

    Exit Function


CleanFail:

    On Error Resume Next

    If fileNum <> 0 Then
        Close #fileNum
    End If

    On Error GoTo 0

    'Any problem reading the permission database
    'defaults to NO leader access.
    IsLeader = False

End Function


Sub leaderTest()


If IsLeader() Then

    MsgBox "Leader access granted."

Else

    MsgBox "Leader access required.", vbExclamation

End If
End Sub
Public Sub MenuRouter(ByVal ActionValue As String)

    Debug.Print "CommandBar Action Clicked: " & ActionValue

    Select Case ActionValue

        Case "EDIT"
            MsgBox "Welcome to the Advanced CommandBar Demo!" & vbNewLine & vbNewLine & _
                   "This menu shows buttons, icons, nested menus, disabled items, checked states, separators, and routed actions.", _
                   vbInformation, "CommandBar Demo"

        Case "DELETE"
            Shell "notepad.exe", vbNormalFocus

        Case "RESOLVE"
            Shell "calc.exe", vbNormalFocus
            
        Case "CLOSE_MENU"
            On Error Resume Next
            Application.CommandBars(DEMO_MENU_NAME).Delete
            On Error GoTo 0

        Case Else
            MsgBox "No action has been assigned for:" & vbNewLine & ActionValue, _
                   vbExclamation, "Unhandled Menu Action"

    End Select

End Sub

Sub createStuff()
    Dim wsShell As Object, shortcut As Object, fso As Object
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set wsShell = CreateObject("WScript.Shell")
    
    If Dir(LOCALFOLDER, vbDirectory) = "" Then
        MkDir LOCALFOLDER
    End If
    
    If Dir(LOCALPATH) = "" Then
        Application.DisplayAlerts = False
        Application.EnableEvents = False
        ThisWorkbook.SaveAs fileName:=LOCALPATH, FileFormat:=xlOpenXMLWorkbookMacroEnabled
        FileCopy ICONPATH, LOCALICONPATH
        Application.EnableEvents = True
        Application.DisplayAlerts = True
    End If

   If Dir(LOCALICONPATH) = "" Then FileCopy ICONPATH, LOCALICONPATH
    
        Set shortcut = wsShell.CreateShortcut(SHORTCUTPATH)
        shortcut.targetPath = LOCALPATH
        shortcut.WorkingDirectory = LOCALFOLDER
        shortcut.IconLocation = LOCALICONPATH
        shortcut.Save

End Sub
