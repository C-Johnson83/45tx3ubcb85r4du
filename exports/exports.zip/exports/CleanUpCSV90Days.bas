Attribute VB_Name = "CleanUpCSV90Days"
Option Explicit


Public Sub PurgeOldDefects()

    Dim csv As CSVEngine
    Dim keys As Collection
    Dim recordKey As Variant
    Dim submittedAt As String
    Dim submittedDate As Date
    Dim cutoffDate As Date
    Dim deletedCount As Long
    Dim backupPath As String
    Dim fso As Object

    On Error GoTo ErrHandler

    Set csv = New CSVEngine
    Set keys = New Collection

    If Not csv.LoadFromFile(DB_PATH, "Submission ID") Then
        Debug.Print "Failed to load CSV."
        Exit Sub
    End If

    cutoffDate = DateAdd("d", -90, Date)

    ' Get all record keys before deleting
    Set keys = csv.Where("Submitted At", "<>")

    ' Check each submission date
    For Each recordKey In keys

        submittedAt = Trim$(csv.GetField( _
            CStr(recordKey), "Submitted At"))

        submittedDate = 0

        If Len(submittedAt) >= 10 Then

            If mid$(submittedAt, 5, 1) = "-" And _
               mid$(submittedAt, 8, 1) = "-" Then

                ' ISO format
                submittedDate = DateSerial( _
                    CInt(Left$(submittedAt, 4)), _
                    CInt(mid$(submittedAt, 6, 2)), _
                    CInt(mid$(submittedAt, 9, 2)))

            ElseIf IsDate(submittedAt) Then

                ' Standard format
                submittedDate = DateValue(CDate(submittedAt))

            End If

            If submittedDate > 0 Then
                If submittedDate < cutoffDate Then
                    If csv.DeleteRow(CStr(recordKey)) Then
                        deletedCount = deletedCount + 1
                    End If
                End If
            End If

        End If

    Next recordKey

    ' Only save when records were removed
    If deletedCount > 0 Then

        Set fso = CreateObject("Scripting.FileSystemObject")

        backupPath = DB_PATH & "." & _
            Format$(Now, "yyyymmdd_hhnnss") & ".bak"

        fso.CopyFile DB_PATH, backupPath, False

        csv.SaveToCsv DB_PATH

    End If

    Debug.Print "--------------------------"
    Debug.Print "90-Day CSV Cleanup"
    Debug.Print "Cutoff Date: " & cutoffDate
    Debug.Print "Records Deleted: " & deletedCount
    Debug.Print "--------------------------"

    Exit Sub

ErrHandler:
    Debug.Print "Purge failed: " & Err.Description

End Sub


