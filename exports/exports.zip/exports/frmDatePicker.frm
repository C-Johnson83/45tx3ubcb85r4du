VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmDatePicker 
   Caption         =   "UserForm2"
   ClientHeight    =   4248
   ClientLeft      =   48
   ClientTop       =   180
   ClientWidth     =   2748
   OleObjectBlob   =   "frmDatePicker.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmDatePicker"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Option Explicit

Private mCurrentMonth As Date
Private mSelectedDate As Date
Private mCancelled As Boolean

Private DayHandlers As Collection

Private Const FORM_WIDTH As Double = 280
Private Const FORM_HEIGHT As Double = 290

Private Const BUTTON_WIDTH As Double = 32
Private Const BUTTON_HEIGHT As Double = 25
Private Const BUTTON_GAP As Double = 3

Private Const LEFT_MARGIN As Double = 12
Private Const TOP_CALENDAR As Double = 55


Private Sub UserForm_Initialize()

    Me.Caption = "Select Date"

    Me.StartUpPosition = 0   ' Manual - required or Top/Left are ignored

    Me.Width = FORM_WIDTH
    Me.Height = FORM_HEIGHT

    ' Convert the frame's position to screen coordinates
    Dim titleBarHeight As Single
    Dim borderWidth As Single
    titleBarHeight = frmDefectForm.Height - frmDefectForm.InsideHeight
    borderWidth = (frmDefectForm.Width - frmDefectForm.InsideWidth) / 2

    Me.Top = frmDefectForm.Top + titleBarHeight + frmDefectForm.Frame1.Top
    Me.Left = frmDefectForm.Left + borderWidth + frmDefectForm.Frame1.Left

    Set DayHandlers = New Collection

    BuildWeekdayHeaders
    BuildDayButtons

End Sub




Private Sub BuildWeekdayHeaders()

    Dim names As Variant
    Dim i As Long
    Dim lbl As MSForms.label
    Dim X As Double

    names = Array("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    For i = 0 To 6

        X = LEFT_MARGIN + _
            (i * (BUTTON_WIDTH + BUTTON_GAP))

        Set lbl = Me.Controls.Add( _
            "Forms.Label.1", _
            "lblWeekday" & i, _
            True)

        With lbl
            .Caption = names(i)
            .Left = X
            .Top = 50
            .Width = BUTTON_WIDTH
            .Height = 16
            .TextAlign = fmTextAlignCenter
            .Font.Bold = True
            .Font.Size = 8
            
        End With

    Next i

End Sub


Private Sub BuildDayButtons()

    Dim i As Long
    Dim rowNumber As Long
    Dim columnNumber As Long

    Dim btn As MSForms.CommandButton
    Dim Handler As cDateButton

    Dim X As Double
    Dim Y As Double

    For i = 1 To 42

        rowNumber = (i - 1) \ 7
        columnNumber = (i - 1) Mod 7

        X = LEFT_MARGIN + _
            (columnNumber * (BUTTON_WIDTH + BUTTON_GAP))

        Y = TOP_CALENDAR + _
            (rowNumber * (BUTTON_HEIGHT + BUTTON_GAP))

        Set btn = Me.Controls.Add( _
            "Forms.CommandButton.1", _
            "cmdDay" & i, _
            True)

        With btn
            .Left = X
            .Top = Y
            .Width = BUTTON_WIDTH
            .Height = BUTTON_HEIGHT
            .Caption = ""
            .Font.name = "Calibri"
            .Font.Size = 12
            .TakeFocusOnClick = False
            .BackColor = RGB(202, 202, 202)
        End With

        Set Handler = New cDateButton

        Set Handler.Button = btn
        Set Handler.ParentForm = Me

        DayHandlers.Add Handler

    Next i

End Sub





Public Sub InitializeCalendar( _
    Optional ByVal StartingDate As Date = 0)

    If StartingDate = 0 Then
        StartingDate = Date
    End If

    mSelectedDate = StartingDate

    mCurrentMonth = DateSerial( _
        Year(StartingDate), _
        Month(StartingDate), _
        1)

    mCancelled = True

    DrawCalendar

End Sub


Private Sub DrawCalendar()

    Dim firstDay As Date
    Dim startingPosition As Long

    Dim daysInMonth As Long
    Dim i As Long

    Dim dayNumber As Long
    Dim buttonIndex As Long

    Dim currentDate As Date
    Dim Handler As cDateButton

    lblMonth.Caption = Format$( _
        mCurrentMonth, _
        "mmmm yyyy")

    firstDay = DateSerial( _
        Year(mCurrentMonth), _
        Month(mCurrentMonth), _
        1)

    startingPosition = Weekday( _
        firstDay, _
        vbSunday)

    daysInMonth = Day( _
        DateSerial( _
            Year(mCurrentMonth), _
            Month(mCurrentMonth) + 1, _
            0))

    'Clear all 42 buttons first
    For i = 1 To 42

        Set Handler = DayHandlers(i)

        Handler.Button.Caption = ""
        Handler.Button.Enabled = False
        Handler.Button.tag = ""
        Handler.Button.BackColor = RGB(202, 202, 202)
    Next i


    'Fill current month
    For dayNumber = 1 To daysInMonth

        buttonIndex = _
            startingPosition + dayNumber - 1

        currentDate = DateSerial( _
            Year(mCurrentMonth), _
            Month(mCurrentMonth), _
            dayNumber)

        Set Handler = DayHandlers(buttonIndex)

        Handler.Button.Caption = _
            CStr(dayNumber)

        Handler.Button.Enabled = True

        Handler.Button.tag = _
            Format$(currentDate, "yyyy-mm-dd")

        Handler.ButtonDate = currentDate


        'Today
        If currentDate = Date Then
            Handler.Button.Font.Bold = True
            Handler.Button.BackColor = RGB(255, 255, 255)
            Handler.Button.ForeColor = RGB(255, 163, 163)
        Else
            Handler.Button.Font.Bold = False
            Handler.Button.BackColor = RGB(255, 163, 163)
            Handler.Button.ForeColor = RGB(0, 0, 0)
        End If

    Next dayNumber

End Sub


Public Sub SelectDate(ByVal SelectedDate As Date)

    mSelectedDate = SelectedDate
    mCancelled = False

    Me.hide

End Sub


Public Property Get SelectedDate() As Date

    SelectedDate = mSelectedDate

End Property


Public Property Get Cancelled() As Boolean

    Cancelled = mCancelled

End Property


Private Sub cmdPrevious_Click()

    mCurrentMonth = DateAdd( _
        "m", _
        -1, _
        mCurrentMonth)

    DrawCalendar

End Sub


Private Sub cmdNext_Click()

    mCurrentMonth = DateAdd( _
        "m", _
        1, _
        mCurrentMonth)

    DrawCalendar

End Sub


Private Sub cmdToday_Click()

    SelectDate Date

End Sub


Private Sub cmdCancel_Click()

    mCancelled = True
    Me.hide

End Sub


Private Sub UserForm_QueryClose( _
    Cancel As Integer, _
    CloseMode As Integer)

    If CloseMode = vbFormControlMenu Then

        Cancel = True
        mCancelled = True

        Me.hide

    End If

End Sub

