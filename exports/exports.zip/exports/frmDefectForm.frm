VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmDefectForm 
   Caption         =   "T-556 Quality Defect Tracker Submission Form"
   ClientHeight    =   9915.001
   ClientLeft      =   108
   ClientTop       =   252
   ClientWidth     =   17988
   OleObjectBlob   =   "frmDefectForm.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmDefectForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit



Private mDescriptionTemplate As String

Private Sub cboDefect_Change()
        Dim ctl As Object

    For Each ctl In Me.Controls

        If ctl.tag = "DefectVariable" Then

            If TypeName(ctl) = "TextBox" Then
                ctl.Value = vbNullString
            End If

        End If

    Next ctl
    
    Me.txtDescription.Value = vbNullString

    Me.cboSubType.Clear
    Me.cboSubType.ListIndex = -1

   

    HideAllVariableFields

    Select Case Me.cboDefect.Value

        Case "Adjustment Error"
            Me.cboSubType.AddItem "Incorrect count adjusted"

        Case "Consolidation Error"
            Me.cboSubType.AddItem "Failed to zero out location"
            Me.cboSubType.AddItem "Combined incorrect items together"
            Me.cboSubType.AddItem "Stacking hazard"

        Case "Duplicate/Swapped Pallet ID"
            Me.cboSubType.AddItem "Pallet has multiple PID numbers"
            Me.cboSubType.AddItem "TM placed wrong PID on both sides"
            Me.cboSubType.AddItem "Duplicate PIDs placed on different pallets"

        Case "Incorrect Count Received"
            Me.cboSubType.AddItem "TM over received"
            Me.cboSubType.AddItem "TM under received"

        Case "Incorrect DPCI Received"
            Me.cboSubType.AddItem "TM received incorrect DPCI"

        Case "Incorrect VCP/SSP Received"
            Me.cboSubType.AddItem "Carton markings did not match pallet ID"

        Case "Labels Left in Location"
            Me.cboSubType.AddItem "TM left labeled freight in location"
            Me.cboSubType.AddItem "TM left loose labels in location"
            Me.cboSubType.AddItem "TM pouched pallet and left in location"

        Case "Mis Pick"
            Me.cboSubType.AddItem "TM picked incorrect amount of Cartons"
            Me.cboSubType.AddItem "TM picked from incorrect location"
            Me.cboSubType.AddItem "TM picked incorrect item"
            Me.cboSubType.AddItem "TM picked incorrect VCP/SSP"
            Me.cboSubType.AddItem "Loose SSPs left in Location"

        Case "Mixed DPCIs on Pallet"
            Me.cboSubType.AddItem "TM received one extra DPCI"
            Me.cboSubType.AddItem "TM received multiple extra DPCIS"

        Case "Non Con Sort Process"
            Me.cboSubType.AddItem "TM failed to scan labels"
            Me.cboSubType.AddItem "TM using CBR instead of CBI"
            Me.cboSubType.AddItem "Undiverted labels thrown in trash"

        Case "Packing Error"
            Me.cboSubType.AddItem "Overage"
            Me.cboSubType.AddItem "Shortage"
            Me.cboSubType.AddItem "Missing"
            Me.cboSubType.AddItem "Unexpected Item"

        Case "Put Error"
            Me.cboSubType.AddItem "TM physically placed pallet in wrong location"
            Me.cboSubType.AddItem "TM created multi-slotted location"
            Me.cboSubType.AddItem "TM placed new pallet on top of an old pallet with items on it"
            Me.cboSubType.AddItem "Pallet physically put, not systematically put"

        Case "Reinstate Error"
            Me.cboSubType.AddItem "Incorrect count reinstated"
            Me.cboSubType.AddItem "Incorrect item reinstated"
            Me.cboSubType.AddItem "Mixed DPCI"
            Me.cboSubType.AddItem "Incorrect VCP/SSP reinstated"

        Case "Verified Not Pulled"
            Me.cboSubType.AddItem "TM turned in labels as NIL when freight was in location"
            Me.cboSubType.AddItem "TM verified fallen pallet cartons"
            Me.cboSubType.AddItem "Did not fulfill partial label demand"

        Case "Face Picked Location"
            Me.cboSubType.AddItem "TM left location face picked"

    End Select

    Me.cboSubType.ListIndex = -1

End Sub


Private Sub cboSubType_Change()
    Dim ctl As Object

    For Each ctl In Me.Controls

        If ctl.tag = "DefectVariable" Then

            If TypeName(ctl) = "TextBox" Then
                ctl.Value = vbNullString
            End If

        End If

    Next ctl
    
    HideAllVariableFields
    mDescriptionTemplate = ""

    Select Case Me.cboSubType.Value

        Case "Incorrect count adjusted"
            mDescriptionTemplate = _
                "Team member adjusted location [[SYSTEM LOCATION]] systematically to [[SYSTEM COUNT]] however physically there were [[PHYSICAL COUNT]] in location. Adjusting the incorrect count results in inventory inaccuracies, NILs, and extra rework."

            ShowField "SystemLocation"
            ShowField "SystemCount"
            ShowField "PhysicalCount"


        Case "Failed to zero out location"
            mDescriptionTemplate = _
                "Team member did not zero out pallet ID from location [[SYSTEM LOCATION]] after they physically moved the freight. This caused additional labels to drop for DPCI [[SYSTEM DPCI]]. Team member was off process by not zeroing out location after removing freight physically from location."

            ShowField "SystemLocation"
            ShowField "SystemDPCI"


        Case "Combined incorrect items together"
            mDescriptionTemplate = _
                "Team member systematically consolidated DPCI [[SYSTEM DPCI]] into location. Physically there additional items [[PHYSICAL DPCI]] in location. Reinstating incorrect freight causes inventory inaccuracies, NILs, and Extra rework. Team member was off process by not verifying items prior to reinstating."

            ShowField "SystemDPCI"
            ShowField "PhysicalDPCI"


        Case "Stacking hazard"
            mDescriptionTemplate = _
                "Due to consolidation stacking, location [[SYSTEM LOCATION]] was found to have multiple damaged units on the lower pallets. This caused a potential fallen pallet hazard and an unsafe work environment. This can also lead to cancels due to incorrect label counts if product is damaged."

            ShowField "SystemLocation"


        Case "Pallet has multiple PID numbers"
            mDescriptionTemplate = _
                "Team member swapped PIDs between two pallets. First Pallet ID ([[SYSTEM PID]]) was for [[SYSTEM COUNT]] cartons of DPCI [[SYSTEM DPCI]] and the second Pallet ID ([[PHYSICAL PID]]) was for [[PHYSICAL COUNT]] cartons of DPCI [[PHYSICAL DPCI]]. PIDs were both placed on incorrect Pallets. Mis-labeling pallets leads to mis-picks and sending the incorrect freight to stores."

            ShowField "SystemPID"
            ShowField "SystemCount"
            ShowField "SystemDPCI"
            ShowField "PhysicalPID"
            ShowField "PhysicalCount"
            ShowField "PhysicalDPCI"


        Case "TM placed wrong PID on both sides"
            mDescriptionTemplate = _
                "Team member mixed up PIDs. First Pallet ID ([[SYSTEM PID]]) was for [[SYSTEM COUNT]] cartons of DPCI [[SYSTEM DPCI]] and the second Pallet ID ([[PHYSICAL PID]]) was for [[PHYSICAL COUNT]] cartons of DPCI [[PHYSICAL DPCI]]. One of each PID was placed on each pallet. Mis-labeling pallets leads to mis-picks and sending the incorrect freight to stores."

            ShowField "SystemPID"
            ShowField "SystemCount"
            ShowField "SystemDPCI"
            ShowField "PhysicalPID"
            ShowField "PhysicalCount"
            ShowField "PhysicalDPCI"


        Case "Duplicate PIDs placed on different pallets"
            mDescriptionTemplate = _
                "Duplicate PIDs were created and placed on different pallets. Incorrect PID [[SYSTEM PID]] was for [[SYSTEM COUNT]] cartons of DPCI [[SYSTEM DPCI]] when the physical product was [[PHYSICAL COUNT]] cartons of DPCI [[PHYSICAL DPCI]]."

            ShowField "SystemPID"
            ShowField "SystemCount"
            ShowField "SystemDPCI"
            ShowField "PhysicalCount"
            ShowField "PhysicalDPCI"


        Case "TM over received"
            mDescriptionTemplate = _
                "Team member systematically received [[SYSTEM COUNT]] cartons of DPCI [[SYSTEM DPCI]]. However physically there are [[PHYSICAL COUNT]] cartons. Over receiving causes cancelled labels and bin inaccuracy. Team member was off process by not verifying correct carton count prior to receiving freight."

            ShowField "SystemCount"
            ShowField "SystemDPCI"
            ShowField "PhysicalCount"


        Case "TM under received"
            mDescriptionTemplate = _
                "Team member systematically received [[SYSTEM COUNT]] cartons of DPCI [[SYSTEM DPCI]]. However physically there are [[PHYSICAL COUNT]] cartons. Under receiving causes bin inaccuracy and excess rework. Team member was off process by not verifying correct carton count prior to receiving freight."

            ShowField "SystemCount"
            ShowField "SystemDPCI"
            ShowField "PhysicalCount"


        Case "TM received incorrect DPCI"
            mDescriptionTemplate = _
                "Team member received [[SYSTEM COUNT]] cartons of DPCI [[SYSTEM DPCI]]. However physically there are [[PHYSICAL COUNT]] cartons of DPCI [[PHYSICAL DPCI]]. Receiving the wrong freight leads to cancelled labels, bin inaccuracy, and sending incorrect freight to stores. Team member was off process by not verifying vendor carton markings prior to receiving freight."

            ShowField "SystemCount"
            ShowField "SystemDPCI"
            ShowField "PhysicalCount"
            ShowField "PhysicalDPCI"


        Case "Carton markings did not match pallet ID"
            mDescriptionTemplate = _
                "Team member received DPCI [[SYSTEM DPCI]] with a VCP/SSP of [[SYSTEM VCP/SSP]]." & vbCrLf & _
                "The carton markings show the correct VCP/SSP which is [[PHYSICAL VCP/SSP]]." & vbCrLf & _
                "Receiving an item as the incorrect VCP/SSP results in an inventory variance and creates additional downstream defects." & vbCrLf & _
                "Team member should always compare carton markings with receiving screen prior to completing receipt."

            ShowField "SystemDPCI"
            ShowField "SystemVCPSSP"
            ShowField "PhysicalVCPSSP"


        Case "TM left labeled freight in location"
            mDescriptionTemplate = _
                "Team member verified and labeled [[IMPACTED LABELS]] items but left labeled freight in location. Team member was off process by not following one piece flow and not verifying all freight was pulled prior to leaving the location per standard work."

            ShowField "ImpactedLabels"


        Case "TM left loose labels in location"
            mDescriptionTemplate = _
                "Team member verified [[IMPACTED LABELS]] labels by [[VERIFICATION METHOD]] but left labels in location. Team member was off process by not verifying all freight was pulled prior to leaving the location per standard work."

            ShowField "ImpactedLabels"
            ShowField "VerificationMethod"


        Case "TM pouched pallet and left in location"
            mDescriptionTemplate = _
                "Team member verified labels by [[VERIFICATION METHOD]], pouched, and placed the pouch on the pallet - however the team member did not pull the pallet from location." & vbCrLf & _
                "The pallet was found in location [[SYSTEM LOCATION]] with label pouch still adhered to the pallet." & vbCrLf & _
                "Team member was off process by not pulling out the pallet prior to placing the pouch on the pallet."

            ShowField "VerificationMethod"
            ShowField "SystemLocation"


        Case "TM picked incorrect amount of Cartons"
            mDescriptionTemplate = _
                "Team member [[OVER/UNDER]] pulled [[SYSTEM LOCATION]] by [[IMPACTED LABELS]] labels. This results in bin inaccuracy and cancelled labels. The team member mis-picked the required freight."

            ShowField "OverUnder"
            ShowField "SystemLocation"
            ShowField "ImpactedLabels"


        Case "TM picked from incorrect location"
            mDescriptionTemplate = _
                "Team member systematically pulled [[IMPACTED LABELS]] from location [[SYSTEM LOCATION]]. However TM physically pulled [[PHYSICAL LOCATION]] causing bin inaccuracy and canceled labels."

            ShowField "ImpactedLabels"
            ShowField "SystemLocation"
            ShowField "PhysicalLocation"


        Case "TM picked incorrect item"
            mDescriptionTemplate = _
                "Team member pulled item [[PHYSICAL DPCI]] when they should have pulled [[SYSTEM DPCI]]. Team member was off process by not verifying correct item was in location prior to pulling freight."

            ShowField "PhysicalDPCI"
            ShowField "SystemDPCI"


        Case "TM picked incorrect VCP/SSP"
            mDescriptionTemplate = _
                "Team member pulled location [[SYSTEM LOCATION]] as [[PHYSICAL VCP/SSP]] when they should have pulled it as [[SYSTEM VCP/SSP]]. Team member should review VCP/SSP training to ensure understanding of how to pull SSPs correctly."

            ShowField "SystemLocation"
            ShowField "PhysicalVCPSSP"
            ShowField "SystemVCPSSP"


        Case "TM received one extra DPCI"
            mDescriptionTemplate = _
                "Team member received [[SYSTEM COUNT]] cartons of DPCI [[SYSTEM DPCI]]. However, [[PHYSICAL COUNT]] of those cartons are DPCI [[PHYSICAL DPCI]]. Multiple DPCI's on a single pallet results in mis-picks and mis-shipments to stores. Team member was off process by not verifying vendor carton markings per standard work."

            ShowField "SystemCount"
            ShowField "SystemDPCI"
            ShowField "PhysicalCount"
            ShowField "PhysicalDPCI"


        Case "TM received multiple extra DPCIS"
            mDescriptionTemplate = _
                "Team member received [[SYSTEM COUNT]] cartons of DPCI [[SYSTEM DPCI]]. However physically there are more than 2 DPCIs on the pallet. Multiple DPCI's on a single pallet results in mis-picks and mis-shipments to stores. TM was off process by not verifying vendor carton markings per standard work."

            ShowField "SystemCount"
            ShowField "SystemDPCI"


        Case "TM failed to scan labels"
            mDescriptionTemplate = _
                "Team member sorting DPCI [[SYSTEM DPCI]] failed to scan [[IMPACTED LABELS]] labels to door [[DOOR]] resulting in aging WIPs and cancelled labels. Team member was off process by not verifying freight successfully scanned to the MCL."

            ShowField "SystemDPCI"
            ShowField "ImpactedLabels"
            ShowField "Door"


        Case "TM using CBR instead of CBI"
            mDescriptionTemplate = _
                "Team member was sorting DPCI [[SYSTEM DPCI]] using jump code CBR instead of CBI. This resulted in [[IMPACTED LABELS]] labels being canceled. TM was off process by using the incorrect jump code."

            ShowField "SystemDPCI"
            ShowField "ImpactedLabels"


        Case "Overage"
            mDescriptionTemplate = _
                "Team member packed [[PHYSICAL COUNT]] when they should have packed [[SYSTEM COUNT]]. This results in extra freight being sent to stores when systematically it is still in our inventory causing inventory shortage."

            ShowField "PhysicalCount"
            ShowField "SystemCount"


        Case "Shortage"
            mDescriptionTemplate = _
                "Team member packed [[PHYSICAL COUNT]] when they should have packed [[SYSTEM COUNT]]. This results in stores not receiving the amount of freight ordered and a potential loss of sales."

            ShowField "PhysicalCount"
            ShowField "SystemCount"


        Case "Missing"
            mDescriptionTemplate = _
                "Team member systematically packed [[SYSTEM COUNT]] units of [[SYSTEM DPCI]], however the physical item is missing. This results in stores not physically receiving the items, causing loss of sales to the store."

            ShowField "SystemCount"
            ShowField "SystemDPCI"


        Case "Unexpected Item"
            mDescriptionTemplate = _
                "Team member physically packed [[PHYSICAL COUNT]] units of [[PHYSICAL DPCI]], however this item is not on the overpack manifest. Sending items not assigned to the carton causes inventory shortage in our building and potential loss of sales for the store that was supposed to receive the item."

            ShowField "PhysicalCount"
            ShowField "PhysicalDPCI"


        Case "TM physically placed pallet in wrong location"
            mDescriptionTemplate = _
                "Team member systematically put product in location [[SYSTEM LOCATION]] using [[PUT METHOD]] but physically placed item in location [[PHYSICAL LOCATION]]. Placing items in the wrong location create bin inaccuracy, NILs, and extra rework."

            ShowField "SystemLocation"
            ShowField "PutMethod"
            ShowField "PhysicalLocation"


        Case "TM created multi-slotted location"
            mDescriptionTemplate = _
                "Team member MNP'd PID [[SYSTEM PID]] into systematically occupied location [[SYSTEM LOCATION]] causing a multi slotted location. Multi-slotting results in NILs, mis-picks, and inventory shortage. Team member should utilize SDP to allow system to direct them to an available location."

            ShowField "SystemPID"
            ShowField "SystemLocation"


        Case "TM placed new pallet on top of an old pallet with items on it"
            mDescriptionTemplate = _
                "Team member placed full pallet in location [[PHYSICAL LOCATION]] which contained a pallet with freight on it. This causes fallen pallet hazards and an unsafe work environment."

            ShowField "PhysicalLocation"


        Case "Pallet physically put, not systematically put"
            mDescriptionTemplate = _
                "Team member placed PID [[PHYSICAL PID]] in location [[PHYSICAL LOCATION]], however they did not systematically add it to the location. This causes inventory inaccuracy and extra rework."

            ShowField "PhysicalPID"
            ShowField "PhysicalLocation"


        Case "Incorrect count reinstated"
            mDescriptionTemplate = _
                "Team member reinstated pallet with the incorrect carton count. Team member reinstated [[SYSTEM COUNT]] cartons of DPCI [[SYSTEM DPCI]] when physically there were [[PHYSICAL COUNT]] cartons. This causes bin inaccuracy and potential NILs. Team member was off process by not verifying Carton Count prior to reinstate."

            ShowField "SystemCount"
            ShowField "SystemDPCI"
            ShowField "PhysicalCount"


        Case "Incorrect item reinstated"
            mDescriptionTemplate = _
                "Team member reinstated pallet with the incorrect DPCI. TM reinstated [[SYSTEM COUNT]] cartons of DPCI [[SYSTEM DPCI]], however physically there are [[PHYSICAL COUNT]] cartons of DPCI [[PHYSICAL DPCI]]. This causes bin inaccuracy and potential NILs. Team member was off process by not verifying DPCI prior to reinstate."

            ShowField "SystemCount"
            ShowField "SystemDPCI"
            ShowField "PhysicalCount"
            ShowField "PhysicalDPCI"


        Case "Mixed DPCI"
            mDescriptionTemplate = _
                "Team member reinstated [[SYSTEM COUNT]] cartons of DPCI [[SYSTEM DPCI]]. However, [[PHYSICAL COUNT]] of those cartons are DPCI [[PHYSICAL DPCI]]. Mixing DPCI's results in mis-picks and mis-shipments to stores. Team member was off process by not verifying vendor carton markings per standard work."

            ShowField "SystemCount"
            ShowField "SystemDPCI"
            ShowField "PhysicalCount"
            ShowField "PhysicalDPCI"


        Case "Incorrect VCP/SSP reinstated"
            mDescriptionTemplate = _
                "Team member reinstated pallet with the incorrect VCP/SSP. Team member reinstated [[SYSTEM COUNT]] cartons of DPCI [[SYSTEM DPCI]] with a VCP/SSP of [[SYSTEM VCP/SSP]]. However the carton markings and physical VCP/SSP is [[PHYSICAL VCP/SSP]]. This causes bin inaccuracy, inventory shortage and potential NILs. Team member was off process by not verifying VCP/SSP prior to reinstating."

            ShowField "SystemCount"
            ShowField "SystemDPCI"
            ShowField "SystemVCPSSP"
            ShowField "PhysicalVCPSSP"


        Case "TM turned in labels as NIL when freight was in location"
            mDescriptionTemplate = _
                "Team member verified the labels for [[SYSTEM LOCATION]] by [[VERIFICATION METHOD]] but did not actually pull the product from the location. The labels associated with these cartons were cancelled when the freight was available in location to pull. If freight is in location but the team member cannot pull for any reason, communicate to label control so the labels are not canceled by ICQA."

            ShowField "SystemLocation"
            ShowField "VerificationMethod"


        Case "TM verified fallen pallet cartons"
            mDescriptionTemplate = _
                "Team member verified the labels by [[VERIFICATION METHOD]] for location [[SYSTEM LOCATION]]. This location contains a fallen pallet and labels should not have been verified. The labels associated with these cartons were cancelled. TM was off process by verifying labels and not turning labels in as Fallen Pallet labels."

            ShowField "VerificationMethod"
            ShowField "SystemLocation"


        Case "Did not fulfill partial label demand"
            mDescriptionTemplate = _
                "Team member verified the labels by [[VERIFICATION METHOD]] for location [[SYSTEM LOCATION]]. This location did not contain enough product to fulfill the label demand, however the Team Member failed to pull what was in the location and turn in any remaining labels as NILs. The labels associated with these cartons were cancelled."

            ShowField "VerificationMethod"
            ShowField "SystemLocation"


        Case "TM left location face picked"
            mDescriptionTemplate = _
                "TM left pallet facepicked after verfying the labels by [[VERIFICATION METHOD]] for location [[SYSTEM LOCATION]]. This created an unsafe work environment for themselves and others. This also can lead to cancelled labels, bin inaccuracy, and sending incorrect freight to stores. TM was off process by not pulling the cartons layer by layer."

            ShowField "VerificationMethod"
            ShowField "SystemLocation"


        Case "Undiverted labels thrown in trash"
            mDescriptionTemplate = _
                "Team member was sorting DPCI [[SYSTEM DPCI]]. TM threw away [[IMPACTED LABELS]] undiverted labels in the trash. This resulted in aging WIPs and these labels being canceled. Extra labels should be turned into the extra label bin after completing each sort loop."

            ShowField "SystemDPCI"
            ShowField "ImpactedLabels"


        Case "Loose SSPs left in Location"
            mDescriptionTemplate = _
                "TM left [[PHYSICAL COUNT]] loose SSPs of DPCI [[PHYSICAL DPCI]] in location [[PHYSICAL LOCATION]]. TM was off process by not leaving the vendor carton until the last SSP was pulled. This can lead to cancelled labels and inventory inaccuracy due to SSPs falling from the racks or getting damaged."

            ShowField "PhysicalCount"
            ShowField "PhysicalDPCI"
            ShowField "PhysicalLocation"

    End Select
UpdateDescription
End Sub

Private Sub UpdateDescription()

    Dim s As String

    'Always start from the untouched original template
    s = mDescriptionTemplate

    s = ReplaceIfEntered(s, "[[SYSTEM LOCATION]]", Me.txtSystemLocation.Value)
    s = ReplaceIfEntered(s, "[[SYSTEM COUNT]]", Me.txtSystemCount.Value)
    s = ReplaceIfEntered(s, "[[PHYSICAL COUNT]]", Me.txtPhysicalCount.Value)

    s = ReplaceIfEntered(s, "[[SYSTEM DPCI]]", Me.txtSystemDPCI.Value)
    s = ReplaceIfEntered(s, "[[PHYSICAL DPCI]]", Me.txtPhysicalDPCI.Value)

    s = ReplaceIfEntered(s, "[[SYSTEM PID]]", Me.txtSystemPID.Value)
    s = ReplaceIfEntered(s, "[[PHYSICAL PID]]", Me.txtPhysicalPID.Value)

    s = ReplaceIfEntered(s, "[[SYSTEM VCP/SSP]]", Me.txtSystemVCPSSP.Value)
    s = ReplaceIfEntered(s, "[[PHYSICAL VCP/SSP]]", Me.txtPhysicalVCPSSP.Value)

    s = ReplaceIfEntered(s, "[[IMPACTED LABELS]]", Me.txtImpactedLabels.Value)
    s = ReplaceIfEntered(s, "[[VERIFICATION METHOD]]", Me.txtVerificationMethod.Value)
    s = ReplaceIfEntered(s, "[[OVER/UNDER]]", Me.txtOverUnder.Value)

    s = ReplaceIfEntered(s, "[[PHYSICAL LOCATION]]", Me.txtPhysicalLocation.Value)
    s = ReplaceIfEntered(s, "[[DOOR]]", Me.txtDoor.Value)
    s = ReplaceIfEntered(s, "[[PUT METHOD]]", Me.txtPutMethod.Value)

    Me.txtDescription.Value = s

End Sub

Private Function ReplaceIfEntered( _
    ByVal templateText As String, _
    ByVal placeholder As String, _
    ByVal enteredValue As String) As String

    If Len(Trim$(enteredValue)) > 0 Then

        ReplaceIfEntered = _
            Replace(templateText, placeholder, enteredValue)

    Else

        'Nothing entered, so leave [[PLACEHOLDER]] alone
        ReplaceIfEntered = templateText

    End If

End Function


Private Sub cmdReportedDate_Click()

     Dim selected As Variant

    selected = PickDate(txtReported.Value)

    If Not IsEmpty(selected) Then

        txtReported.Value = _
            Format$(selected, "yyyy-mm-dd")

    End If

End Sub

Private Sub cmdSelectImage1_Click()

    Dim fd As FileDialog

    Set fd = Application.FileDialog(msoFileDialogFilePicker)

    With fd

        .Title = "Select Defect Photo"
        .AllowMultiSelect = False

        .filters.Clear
        .filters.Add "Image Files", "*.jpg;*.jpeg;*.png;*.bmp"

        If .Show = -1 Then
            Me.txtImagePath1.Value = .SelectedItems(1)
        End If

    End With

    Set fd = Nothing

End Sub
Private Sub cmdSelectImage2_Click()

    Dim fd As FileDialog

    Set fd = Application.FileDialog(msoFileDialogFilePicker)

    With fd

        .Title = "Select Defect Photo"
        .AllowMultiSelect = False

        .filters.Clear
        .filters.Add "Image Files", "*.jpg;*.jpeg;*.png;*.bmp"

        If .Show = -1 Then
            Me.txtImagePath2.Value = .SelectedItems(1)
        End If

    End With

    Set fd = Nothing

End Sub
Private Function SaveSubmissionImage( _
    ByVal sourcePath As String, _
    ByVal submissionID As String, _
    ByVal imageNumber As Long) As String

    Dim fso As Object
    Dim dbFolder As String
    Dim attachmentsFolder As String
    Dim submissionFolder As String
    Dim extension As String
    Dim destinationPath As String
    Dim fileName As String

    SaveSubmissionImage = ""

    If Len(Trim$(sourcePath)) = 0 Then Exit Function

    'Only allow Image 1 or Image 2
    If imageNumber <> 1 And imageNumber <> 2 Then

        MsgBox _
            "Invalid image number: " & imageNumber, _
            vbExclamation, _
            "Image Error"

        Exit Function

    End If

    Set fso = CreateObject("Scripting.FileSystemObject")

    'Make sure selected image still exists
    If Not fso.fileExists(sourcePath) Then

        MsgBox _
            "The selected image could not be found:" & vbCrLf & vbCrLf & _
            sourcePath, _
            vbExclamation, _
            "Image Not Found"

        Set fso = Nothing
        Exit Function

    End If

    'Folder containing Defect_Submissions.csv
    dbFolder = fso.GetParentFolderName(DB_PATH)

    'Shared attachment folder
    attachmentsFolder = _
        fso.BuildPath(dbFolder, "Attachments")

    If Not fso.FolderExists(attachmentsFolder) Then
        fso.CreateFolder attachmentsFolder
    End If

    'Folder specifically for this submission
    submissionFolder = _
        fso.BuildPath(attachmentsFolder, submissionID)

    If Not fso.FolderExists(submissionFolder) Then
        fso.CreateFolder submissionFolder
    End If

    'Get original file extension
    extension = fso.GetExtensionName(sourcePath)

    'Build Photo_1 or Photo_2 filename
    fileName = "Photo_" & CStr(imageNumber)

    If Len(extension) > 0 Then
        fileName = fileName & "." & extension
    End If

    'Build complete destination path
    destinationPath = _
        fso.BuildPath(submissionFolder, fileName)

    'Copy image
    On Error GoTo CopyError

    fso.CopyFile sourcePath, destinationPath, True

    'Return permanent shared path
    SaveSubmissionImage = destinationPath

    Set fso = Nothing

    Exit Function


CopyError:

    MsgBox _
        "The image could not be copied to the shared database." & _
        vbCrLf & vbCrLf & _
        "Error " & Err.Number & ": " & Err.Description, _
        vbCritical, _
        "Image Copy Error"

    Set fso = Nothing

End Function
Private Sub Label19_Click()

End Sub

Private Sub txtZNumber_Change()

End Sub

    Private Sub txtZNumber_Exit(ByVal Cancel As MSForms.ReturnBoolean)
        ZLookup
        
        DebugDefectTally
    End Sub

Private Sub UserForm_Initialize()
    TagDefectVariableControls
    Me.Height = 460
    Me.Width = 700
    With Me.cboDefect
        .Clear
        
        .AddItem "Adjustment Error"
        .AddItem "Consolidation Error"
        .AddItem "Duplicate/Swapped Pallet ID"
        .AddItem "Incorrect Count Received"
        .AddItem "Incorrect DPCI Received"
        .AddItem "Incorrect VCP/SSP Received"
        .AddItem "Labels Left in Location"
        .AddItem "Mis Pick"
        .AddItem "Mixed DPCIs on Pallet"
        .AddItem "Non Con Sort Process"
        .AddItem "Packing Error"
        .AddItem "Put Error"
        .AddItem "Reinstate Error"
        .AddItem "Verified Not Pulled"
        .AddItem "Face Picked Location"
        
        .Style = fmStyleDropDownList
        .ListIndex = -1
    End With

    With Me.cboSubType
        .Clear
        .Style = fmStyleDropDownList
        .ListIndex = -1
    End With
txtAuditor.Value = Application.UserName
    HideAllVariableFields
End Sub
Private Sub TagDefectVariableControls()

    Dim fields As Variant
    Dim i As Long

    fields = Array( _
        "SystemLocation", _
        "SystemCount", _
        "PhysicalCount", _
        "SystemDPCI", _
        "PhysicalDPCI", _
        "SystemPID", _
        "PhysicalPID", _
        "SystemVCPSSP", _
        "PhysicalVCPSSP", _
        "ImpactedLabels", _
        "VerificationMethod", _
        "OverUnder", _
        "PhysicalLocation", _
        "Door", _
        "PutMethod" _
    )

    For i = LBound(fields) To UBound(fields)

        Me.Controls("txt" & fields(i)).tag = "DefectVariable"
        Me.Controls("lbl" & fields(i)).tag = "DefectVariable"

    Next i

End Sub

Private Sub ShowField(ByVal fieldName As String)

    Me.Controls("lbl" & fieldName).Visible = True
    Me.Controls("txt" & fieldName).Visible = True

End Sub
Private Sub HideAllVariableFields()

    Dim ctl As Object

    For Each ctl In Me.Controls

        If ctl.tag = "DefectVariable" Then
            ctl.Visible = False
        End If

    Next ctl

End Sub

'============================================================
' SUBMISSION
'============================================================


Private Sub cbct_Click()
    SubmitDefect
End Sub


Private Sub SubmitDefect()

    Dim recordData As Variant
    Dim finalDescription As String
    Dim submissionID As String
    Dim savedImagePath As String
    Dim savedImagePath2 As String
    
    If Me.cboDefect.ListIndex = -1 Then
        MsgBox "Please select a defect.", vbExclamation, "Missing Defect"
        Me.cboDefect.SetFocus
        Exit Sub
    End If

    If Me.cboSubType.ListIndex = -1 Then
        MsgBox "Please select a subtype.", vbExclamation, "Missing Subtype"
        Me.cboSubType.SetFocus
        Exit Sub
    End If

    If Not ValidateVisibleFields Then Exit Sub

    If Len(Trim$(Me.txtDescription.Value)) = 0 Then
        MsgBox "No defect description is loaded.", vbExclamation, "Missing Description"
        Exit Sub
    End If

    finalDescription = BuildFinalDescription()

    submissionID = GetNextSubmissionID()
    
    If Len(submissionID) = 0 Then
        Exit Sub
    End If

    'IMPORTANT:
    'This order matches the CSV header structure previously created:
    '
    'Submission ID
    'Submitted At
    'Date of Defect
    'z number
    'Name
    'Key
    'Supervisor
    'Defect
    'Sub Type
    'Impact Label Calc
    'Description Template
    'Additional Details
    'System Location
    'System Count
    'Physical Count
    'System DPCI
    'Physical DPCI
    'System PID
    'Physical PID
    'System VCP/SSP
    'Physical VCP/SSP
    'Impacted Labels
    'Verification Method
    'Over/Under
    'Physical Location
    'Door
    'Put Method
    'Image 1 Path
    'Image 2 Path
    'Resolved

    If Len(Trim$(Me.txtImagePath1.Value)) > 0 Then

    savedImagePath = _
        SaveSubmissionImage( _
            Me.txtImagePath1.Value, _
            submissionID, 1)

    If Len(savedImagePath) = 0 Then
        Exit Sub
    End If

End If

If Len(Trim$(Me.txtImagePath2.Value)) > 0 Then

    savedImagePath2 = _
        SaveSubmissionImage( _
            Me.txtImagePath2.Value, _
            submissionID, 2)

    If Len(savedImagePath2) = 0 Then
        Exit Sub
    End If

End If
  
    recordData = Array( _
        submissionID, _
        Format$(Now, "yyyy-mm-dd hh:nn:ss"), _
        Me.txtReported.Value, Me.txtZNumber.Value, _
        Me.txtName.Value, Me.txtKey.Value, Me.txtSuper.Value, Me.cboDefect.Value, _
        Me.cboSubType.Value, _
        GetImpactLabelCalc(Me.cboSubType.Value), _
        Me.txtDescription.Value, _
        Me.txtComments, _
        Me.txtSystemLocation.Value, _
        Me.txtSystemCount.Value, _
        Me.txtPhysicalCount.Value, _
        Me.txtSystemDPCI.Value, _
        Me.txtPhysicalDPCI.Value, _
        Me.txtSystemPID.Value, _
        Me.txtPhysicalPID.Value, _
        Me.txtSystemVCPSSP.Value, _
        Me.txtPhysicalVCPSSP.Value, _
        Me.txtImpactedLabels.Value, _
        Me.txtVerificationMethod.Value, _
        Me.txtOverUnder.Value, _
        Me.txtPhysicalLocation.Value, _
        Me.txtDoor.Value, _
        Me.txtPutMethod.Value, _
        savedImagePath, savedImagePath2)

    If AppendCSVRecord(DB_PATH, recordData) Then
    SendEmail
        MsgBox _
            "Defect submitted successfully." & vbCrLf & vbCrLf & _
            "Submission ID: " & submissionID, _
            vbInformation, _
            "Submission Complete"

        ClearDefectForm

    End If

End Sub
Private Sub SendEmail()

    Dim EmailBody As String
    Dim EmailSubject As String
    Dim Lcalc As String
    Lcalc = GetImpactLabelCalc(Me.cboSubType.Value)
    EmailBody = BuildDefectEmail( _
        Me.txtKey.Value, _
        Me.txtName.Value, _
        Me.txtReported.Value, _
        "ICQA OM", _
        "1", _
        Lcalc, _
        Me.cboDefect.Value, _
        Me.cboSubType.Value, _
        Me.txtDescription.Value)

    EmailSubject = "Defect Entry Added"

    If SendNotification(Lcalc, Me.txtKey.Value, EmailSubject, EmailBody) Then
        MsgBox "Notification submitted successfully."
    End If

End Sub

'============================================================
' CSV DATABASE WRITE
'============================================================

Private Function AppendCSVRecord( _
    ByVal filePath As String, _
    ByVal values As Variant) As Boolean

    Dim fileNum As Integer
    Dim csvLine As String
    Dim headerLine As String
    Dim i As Long
    Dim startTime As Single
    Dim elapsed As Single
    Dim retrySeconds As Single
    Dim openErrNumber As Long
    Dim openErrDescription As String
    Dim fileExists As Boolean

    AppendCSVRecord = False
    retrySeconds = 10

    If Len(Trim$(filePath)) = 0 Then
        MsgBox "The database path has not been configured.", _
               vbCritical, "Database Path"
        Exit Function
    End If

    '--------------------------------------------------
    ' Build submission record
    '--------------------------------------------------
    For i = LBound(values) To UBound(values)

        If i > LBound(values) Then
            csvLine = csvLine & ","
        End If

        csvLine = csvLine & CSVSafe(values(i))

    Next i

    '--------------------------------------------------
    ' Build database header
    '--------------------------------------------------
    headerLine = BuildCSVHeader()

    '--------------------------------------------------
    ' Check whether database currently exists
    '--------------------------------------------------
    fileExists = (Len(Dir$(filePath)) > 0)

    '--------------------------------------------------
    ' Attempt to open/create database with exclusive lock
    '--------------------------------------------------
    startTime = Timer

RetryOpen:

    fileNum = FreeFile
    Err.Clear

    On Error Resume Next

    Open filePath For Append _
        Access Write _
        Lock Read Write _
        As #fileNum

    openErrNumber = Err.Number
    openErrDescription = Err.Description

    On Error GoTo 0

    '--------------------------------------------------
    ' Couldn't obtain access
    '--------------------------------------------------
    If openErrNumber <> 0 Then

        On Error Resume Next
        Close #fileNum
        On Error GoTo 0

        DoEvents

        'Handle midnight rollover
        If Timer >= startTime Then
            elapsed = Timer - startTime
        Else
            elapsed = (86400 - startTime) + Timer
        End If

        If elapsed < retrySeconds Then
            GoTo RetryOpen
        End If

        MsgBox _
            "The submission database is currently busy or unavailable." & _
            vbCrLf & vbCrLf & _
            "The form waited " & retrySeconds & _
            " seconds but could not obtain access." & _
            vbCrLf & vbCrLf & _
            "Database:" & vbCrLf & filePath & _
            vbCrLf & vbCrLf & _
            "Details: " & openErrDescription, _
            vbExclamation, _
            "Database Busy"

        Exit Function

    End If

    On Error GoTo WriteError

    '--------------------------------------------------
    ' If this is a new file, write headers first
    '--------------------------------------------------
    If Not fileExists Then
        Print #fileNum, headerLine
    End If

    '--------------------------------------------------
    ' Append submission
    '--------------------------------------------------
    Print #fileNum, csvLine

    Close #fileNum

    AppendCSVRecord = True
    Exit Function


WriteError:

    Dim writeErrNumber As Long
    Dim writeErrDescription As String

    writeErrNumber = Err.Number
    writeErrDescription = Err.Description

    On Error Resume Next
    Close #fileNum
    On Error GoTo 0

    MsgBox _
        "The submission could not be saved." & _
        vbCrLf & vbCrLf & _
        "Error " & writeErrNumber & ": " & _
        writeErrDescription, _
        vbCritical, _
        "Submission Error"

End Function
Private Function BuildCSVHeader() As String

    Dim headers As Variant
    Dim s As String
    Dim i As Long

    headers = Array( _
        "Submission ID", _
        "Submitted At", _
        "Submitted By", "Z Number", _
        "Defect", _
        "Sub Type", _
        "Impact Label Calc", _
        "Description Template", _
        "Final Description", _
        "System Location", _
        "System Count", _
        "Physical Count", _
        "System DPCI", _
        "Physical DPCI", _
        "System PID", _
        "Physical PID", _
        "System VCP/SSP", _
        "Physical VCP/SSP", _
        "Impacted Labels", _
        "Verification Method", _
        "Over/Under", _
        "Physical Location", _
        "Door", _
        "Put Method", _
        "Image 1 Path", "Image 2 Path")

    For i = LBound(headers) To UBound(headers)

        If i > LBound(headers) Then
            s = s & ","
        End If

        s = s & CSVSafe(headers(i))

    Next i

    BuildCSVHeader = s

End Function

Private Function CSVSafe(ByVal Value As Variant) As String

    Dim s As String

    If IsError(Value) Then
        s = ""
    ElseIf IsNull(Value) Or IsEmpty(Value) Then
        s = ""
    Else
        s = CStr(Value)
    End If

    'Escape embedded double-quotes according to CSV rules.
    s = Replace(s, """", """""")

    'Always quote each field.
    'This safely handles commas and line breaks in the description.
    CSVSafe = """" & s & """"

End Function


Private Function CleanIDPart(ByVal Value As String) As String

    Dim s As String

    s = Trim$(Value)

    s = Replace(s, " ", "_")
    s = Replace(s, "\", "_")
    s = Replace(s, "/", "_")
    s = Replace(s, ",", "_")
    s = Replace(s, """", "_")

    CleanIDPart = s

End Function


'============================================================
' DESCRIPTION REPLACEMENT
'============================================================

Private Function BuildFinalDescription() As String

    Dim s As String

    s = Me.txtDescription.Value

    s = Replace(s, "[[SYSTEM LOCATION]]", Me.txtSystemLocation.Value)
    s = Replace(s, "[[SYSTEM COUNT]]", Me.txtSystemCount.Value)
    s = Replace(s, "[[PHYSICAL COUNT]]", Me.txtPhysicalCount.Value)

    s = Replace(s, "[[SYSTEM DPCI]]", Me.txtSystemDPCI.Value)
    s = Replace(s, "[[PHYSICAL DPCI]]", Me.txtPhysicalDPCI.Value)

    s = Replace(s, "[[SYSTEM PID]]", Me.txtSystemPID.Value)
    s = Replace(s, "[[PHYSICAL PID]]", Me.txtPhysicalPID.Value)

    s = Replace(s, "[[SYSTEM VCP/SSP]]", Me.txtSystemVCPSSP.Value)
    s = Replace(s, "[[PHYSICAL VCP/SSP]]", Me.txtPhysicalVCPSSP.Value)

    s = Replace(s, "[[IMPACTED LABELS]]", Me.txtImpactedLabels.Value)
    s = Replace(s, "[[VERIFICATION METHOD]]", Me.txtVerificationMethod.Value)
    s = Replace(s, "[[OVER/UNDER]]", Me.txtOverUnder.Value)

    s = Replace(s, "[[PHYSICAL LOCATION]]", Me.txtPhysicalLocation.Value)
    s = Replace(s, "[[DOOR]]", Me.txtDoor.Value)
    s = Replace(s, "[[PUT METHOD]]", Me.txtPutMethod.Value)

    BuildFinalDescription = s

End Function
Private Sub txtSystemLocation_Change()

    UpdateDescription

End Sub
Private Sub txtSystemCount_Change()
    UpdateDescription
End Sub

Private Sub txtPhysicalCount_Change()
    UpdateDescription
End Sub

Private Sub txtSystemDPCI_Change()
    UpdateDescription
End Sub

Private Sub txtPhysicalDPCI_Change()
    UpdateDescription
End Sub

Private Sub txtSystemPID_Change()
    UpdateDescription
End Sub

Private Sub txtPhysicalPID_Change()
    UpdateDescription
End Sub

Private Sub txtSystemVCPSSP_Change()
    UpdateDescription
End Sub

Private Sub txtPhysicalVCPSSP_Change()
    UpdateDescription
End Sub

Private Sub txtImpactedLabels_Change()
    UpdateDescription
End Sub

Private Sub txtVerificationMethod_Change()
    UpdateDescription
End Sub

Private Sub txtOverUnder_Change()
    UpdateDescription
End Sub

Private Sub txtPhysicalLocation_Change()
    UpdateDescription
End Sub

Private Sub txtDoor_Change()
    UpdateDescription
End Sub

Private Sub txtPutMethod_Change()
    UpdateDescription
End Sub
'============================================================
' IMPACT LABEL CALC LOOKUP
'============================================================

'Private Function GetImpactLabelCalc(ByVal subType As String) As String
'
'    Select Case subType
'
'        Case "Incorrect count adjusted", _
'             "TM under received", _
'             "Overage", _
'             "TM turned in labels as NIL when freight was in location", _
'             "TM verified fallen pallet cartons", _
'             "Did not fulfill partial label demand"
'
'            GetImpactLabelCalc = "phys count - system count"
'
'
'        Case "TM over received", _
'             "Shortage", _
'             "Incorrect count reinstated"
'
'            GetImpactLabelCalc = "sys count - phys count"
'
'
'        Case "Pallet has multiple PID numbers", _
'             "TM placed wrong PID on both sides", _
'             "Duplicate PIDs placed on different pallets"
'
'            GetImpactLabelCalc = "phys count + sys count"
'
'
'        Case "Incorrect item reinstated"
'
'            GetImpactLabelCalc = "sys count + phys count"
'
'
'        Case "TM received one extra DPCI", _
'             "TM received multiple extra DPCIS", _
'             "Unexpected Item", _
'             "Pallet physically put, not systematically put", _
'             "Mixed DPCI"
'
'            GetImpactLabelCalc = "phys count"
'
'
'        Case "TM left labeled freight in location", _
'             "TM left loose labels in location", _
'             "TM pouched pallet and left in location", _
'             "TM picked incorrect amount of Cartons", _
'             "TM picked from incorrect location", _
'             "TM picked incorrect item", _
'             "TM picked incorrect VCP/SSP", _
'             "TM failed to scan labels", _
'             "TM using CBR instead of CBI", _
'             "Undiverted labels thrown in trash", _
'             "Loose SSPs left in Location"
'
'            GetImpactLabelCalc = "impacted labels"
'
'
'        Case "Stacking hazard"
'
'            GetImpactLabelCalc = "1"
'
'
'        Case Else
'
'            GetImpactLabelCalc = "sys count"
'
'    End Select
'
'End Function


'============================================================
' VALIDATION
'============================================================

Private Function ValidateVisibleFields() As Boolean

    Dim ctl As Object
    Dim fieldLabel As String

    ValidateVisibleFields = False

    For Each ctl In Me.Controls

        If ctl.tag = "DefectVariable" Then

            If TypeName(ctl) = "TextBox" Then

                If ctl.Visible Then

                    If Len(Trim$(CStr(ctl.Value))) = 0 Then

                        fieldLabel = GetVariableLabelCaption(ctl.name)

                        MsgBox _
                            "Please enter a value for " & fieldLabel & ".", _
                            vbExclamation, _
                            "Missing Information"

                        ctl.SetFocus
                        Exit Function

                    End If

                End If

            End If

        End If

    Next ctl

    ValidateVisibleFields = True

End Function


Private Function GetVariableLabelCaption(ByVal textBoxName As String) As String

    Dim fieldName As String
    Dim labelName As String
    Dim captionText As String

    If Left$(textBoxName, 3) = "txt" Then
        fieldName = mid$(textBoxName, 4)
    Else
        fieldName = textBoxName
    End If

    labelName = "lbl" & fieldName

    On Error Resume Next
    captionText = Me.Controls(labelName).Caption
    On Error GoTo 0

    captionText = Replace(captionText, ":", "")

    If Len(Trim$(captionText)) = 0 Then
        captionText = fieldName
    End If

    GetVariableLabelCaption = captionText

End Function


'============================================================
' CLEAR FORM AFTER SUCCESSFUL SUBMISSION
'============================================================

Private Sub ClearDefectForm()

    Dim ctl As Object

    For Each ctl In Me.Controls

        If ctl.tag = "DefectVariable" Then

            If TypeName(ctl) = "TextBox" Then
                ctl.Value = vbNullString
            End If

        End If

    Next ctl

    Me.txtDescription.Value = vbNullString

    Me.cboSubType.Clear
    Me.cboSubType.ListIndex = -1

    Me.cboDefect.ListIndex = -1

    HideAllVariableFields

    Me.cboDefect.SetFocus

End Sub


Private Function GetNextSubmissionID() As String

    Dim fso As Object
    Dim dbFolder As String
    Dim counterPath As String

    Dim fileNum As Integer
    Dim currentNumber As Long
    Dim nextNumber As Long
    Dim counterText As String
    Dim newCounterText As String

    Dim startTime As Single
    Dim elapsed As Single
    Dim retrySeconds As Single

    Dim openErrNumber As Long
    Dim openErrDescription As String

    Dim errNumber As Long
    Dim errDescription As String

    '--------------------------------------------------
    ' Default return value = failure
    '--------------------------------------------------
    GetNextSubmissionID = vbNullString

    retrySeconds = 10

    '--------------------------------------------------
    ' Locate counter file beside CSV database
    '--------------------------------------------------
    Set fso = CreateObject("Scripting.FileSystemObject")

    dbFolder = fso.GetParentFolderName(DB_PATH)

    If Len(dbFolder) = 0 Then

        MsgBox _
            "Could not determine the database folder." & _
            vbCrLf & vbCrLf & _
            "Check DB_PATH at the top of the form.", _
            vbCritical, _
            "Submission ID Error"

        Set fso = Nothing
        Exit Function

    End If

    If Not fso.FolderExists(dbFolder) Then

        MsgBox _
            "The database folder could not be found:" & _
            vbCrLf & vbCrLf & _
            dbFolder, _
            vbCritical, _
            "Submission ID Error"

        Set fso = Nothing
        Exit Function

    End If

    counterPath = _
        fso.BuildPath(dbFolder, "SubmissionCounter.txt")

    '--------------------------------------------------
    ' Attempt to exclusively lock counter file
    '
    ' If the file does not exist, Binary mode will
    ' create it.
    '--------------------------------------------------
    startTime = Timer

RetryOpen:

    fileNum = FreeFile

    Err.Clear

    On Error Resume Next

    Open counterPath For Binary _
        Access Read Write _
        Lock Read Write _
        As #fileNum

    openErrNumber = Err.Number
    openErrDescription = Err.Description

    On Error GoTo 0

    '--------------------------------------------------
    ' Could not obtain lock
    '--------------------------------------------------
    If openErrNumber <> 0 Then

        On Error Resume Next
        Close #fileNum
        On Error GoTo 0

        DoEvents

        'Handle Timer resetting at midnight
        If Timer >= startTime Then
            elapsed = Timer - startTime
        Else
            elapsed = (86400 - startTime) + Timer
        End If

        If elapsed < retrySeconds Then
            GoTo RetryOpen
        End If

        MsgBox _
            "The submission number file is currently busy " & _
            "or unavailable." & _
            vbCrLf & vbCrLf & _
            "The form waited " & retrySeconds & _
            " seconds for access." & _
            vbCrLf & vbCrLf & _
            "Please try submitting again." & _
            vbCrLf & vbCrLf & _
            "Counter file:" & vbCrLf & _
            counterPath & _
            vbCrLf & vbCrLf & _
            "Details: " & openErrDescription, _
            vbExclamation, _
            "Submission ID Busy"

        Set fso = Nothing
        Exit Function

    End If

    'From here until Close #fileNum, this user owns
    'the exclusive lock on the counter file.
    On Error GoTo CounterError

    '--------------------------------------------------
    ' Read current counter
    '--------------------------------------------------
    If LOF(fileNum) = 0 Then

        'Brand-new counter file
        currentNumber = 0

    Else

        counterText = Space$(LOF(fileNum))

        Get #fileNum, 1, counterText

        counterText = Trim$(counterText)

        If Len(counterText) = 0 Then

            currentNumber = 0

        ElseIf IsNumeric(counterText) Then

            currentNumber = CLng(counterText)

        Else

            'Do NOT reset a damaged counter to zero.
            'That could cause an old ID to be reused.
            Close #fileNum

            MsgBox _
                "The submission counter file contains an " & _
                "invalid value:" & _
                vbCrLf & vbCrLf & _
                counterText & _
                vbCrLf & vbCrLf & _
                "No submission ID was issued.", _
                vbCritical, _
                "Invalid Submission Counter"

            Set fso = Nothing
            Exit Function

        End If

    End If

    '--------------------------------------------------
    ' Generate next number
    '--------------------------------------------------
    If currentNumber >= 999999 Then

        Close #fileNum

        MsgBox _
            "The submission ID counter has reached " & _
            "its maximum value of 999999.", _
            vbCritical, _
            "Submission ID Limit Reached"

        Set fso = Nothing
        Exit Function

    End If

    nextNumber = currentNumber + 1

    newCounterText = _
        Format$(nextNumber, "000000")

    '--------------------------------------------------
    ' Save new counter while we STILL own the lock
    '--------------------------------------------------
    Seek #fileNum, 1

    Put #fileNum, , newCounterText

    'Counter is always exactly 6 characters,
    'so no SetEOF is necessary.

    Close #fileNum

    '--------------------------------------------------
    ' Return the new Submission ID
    '--------------------------------------------------
    GetNextSubmissionID = newCounterText

    Set fso = Nothing

    Exit Function


CounterError:

    errNumber = Err.Number
    errDescription = Err.Description

    On Error Resume Next
    Close #fileNum
    On Error GoTo 0

    Set fso = Nothing

    MsgBox _
        "The next submission ID could not be generated." & _
        vbCrLf & vbCrLf & _
        "Error " & errNumber & ": " & errDescription, _
        vbCritical, _
        "Submission ID Error"

End Function

Private Sub ZLookup()

' Capitalize all input on exit
txtZNumber.text = UCase(txtZNumber.text)
Application.ScreenUpdating = False

Dim lookupValue As String
Dim lineData As String
Dim fields() As String
Dim fNum As Integer
Dim found As Boolean

lookupValue = UCase(Trim(txtZNumber.text))

If lookupValue = "" Then GoTo ExitRoutine

fNum = FreeFile
found = False

Open tmdbcsv For Input As #fNum
    Do While Not EOF(fNum)
        Line Input #fNum, lineData
        If Trim(lineData) = "" Then GoTo ContinueLoop
        fields = ParseCSVLine(lineData)
        If UBound(fields) < 3 Then GoTo ContinueLoop
        If UCase(Trim(fields(0))) = lookupValue Then
            Me.txtName.text = fields(2) & "," & fields(1)
            Me.txtKey.text = fields(8)
            Me.txtSuper.text = fields(12)
           ' Key = fields(3)
            found = True
            Exit Do
        End If
ContinueLoop:
    Loop
Close #fNum

If Not found Then
    Me.txtName.text = "Not found"
    Me.txtKey.text = "Not found"
End If

ExitRoutine:
Application.ScreenUpdating = True
End Sub



Private Function GetImpactLabelCalc(ByVal subType As String) As String

    Select Case subType

        Case "Incorrect count adjusted", _
             "TM under received", _
             "Overage", _
             "TM turned in labels as NIL when freight was in location", _
             "TM verified fallen pallet cartons", _
             "Did not fulfill partial label demand"
Debug.Print "Returning: [" & GetImpactLabelCalc & "]"
           ' GetImpactLabelCalc = "phys count - system count"
GetImpactLabelCalc = CStr(Me.txtPhysicalCount.Value - Me.txtSystemCount.Value)

        Case "TM over received", _
             "Shortage", _
             "Incorrect count reinstated"
Debug.Print "Returning: [" & GetImpactLabelCalc & "]"
         '   GetImpactLabelCalc = "sys count - phys count"
GetImpactLabelCalc = CStr(Me.txtSystemCount.Value - Me.txtPhysicalCount.Value)

        Case "Pallet has multiple PID numbers", _
             "TM placed wrong PID on both sides", _
             "Duplicate PIDs placed on different pallets"
Debug.Print "Returning: [" & GetImpactLabelCalc & "]"
            'GetImpactLabelCalc = "phys count + sys count"
GetImpactLabelCalc = CStr(Me.txtPhysicalCount.Value + Me.txtSystemCount.Value)

        Case "Incorrect item reinstated"
Debug.Print "Returning: [" & GetImpactLabelCalc & "]"
          '  GetImpactLabelCalc = "sys count + phys count"
GetImpactLabelCalc = CStr(Me.txtSystemCount.Value + Me.txtPhysicalCount.Value)

        Case "TM received one extra DPCI", _
             "TM received multiple extra DPCIS", _
             "Unexpected Item", _
             "Pallet physically put, not systematically put", _
             "Mixed DPCI"
Debug.Print "Returning: [" & GetImpactLabelCalc & "]"
           ' GetImpactLabelCalc = "phys count"
GetImpactLabelCalc = CStr(Me.txtPhysicalCount.Value)

        Case "TM left labeled freight in location", _
             "TM left loose labels in location", _
             "TM pouched pallet and left in location", _
             "TM picked incorrect amount of Cartons", _
             "TM picked from incorrect location", _
             "TM picked incorrect item", _
             "TM picked incorrect VCP/SSP", _
             "TM failed to scan labels", _
             "TM using CBR instead of CBI", _
             "Undiverted labels thrown in trash", _
             "Loose SSPs left in Location"
Debug.Print "Returning: [" & GetImpactLabelCalc & "]"
            GetImpactLabelCalc = "impacted labels"
    GetImpactLabelCalc = CStr(Me.txtImpactedLabels.Value)

        Case "Stacking hazard"

            GetImpactLabelCalc = "1"


        Case Else

         '   GetImpactLabelCalc = "sys count"
GetImpactLabelCalc = CStr(Me.txtSystemCount.Value)
    End Select

End Function


'Private Sub DebugDefectTally()
'
'    Dim csv As CSVEngine
'    Dim matches As Collection
'    Dim zNum As String
'
'    zNum = Trim$(Me.txtZNumber.Value)
'
'    If Len(zNum) = 0 Then Exit Sub
'
'    Set csv = New CSVEngine
'
'    If Not csv.LoadFromFile(DB_PATH, "Submission ID") Then
'        Debug.Print "Failed to load defect CSV."
'        Exit Sub
'    End If
'
'    Set matches = csv.FindExact("Z Number", zNum)
'
'    Debug.Print "--------------------------"
'    Debug.Print "Z Number: " & zNum
'    Debug.Print "Defect Count: " & matches.Count
'    Debug.Print "--------------------------"
'
'End Sub
'---------------------------------------------------------------------------------------------------------------
'Private Sub DebugDefectTally()
'
'    Dim csv As CSVEngine
'    Dim matches As Collection
'    Dim agingMatches As Long
'    Dim recordKey As Variant
'    Dim submittedAt As String
'    Dim zNum As String
'
'    zNum = Trim$(Me.txtZNumber.Value)
'
'    If Len(zNum) = 0 Then Exit Sub
'
'    Set csv = New CSVEngine
'
'    If Not csv.LoadFromFile(DB_PATH, "Submission ID") Then
'        Debug.Print "Failed to load defect CSV."
'        Exit Sub
'    End If
'
'    Set matches = csv.FindExact("Z Number", zNum)
'
'agingMatches = 0
'
'Dim submittedDate As Date
'
'For Each recordKey In matches
'
'    submittedAt = Trim$(csv.GetField( _
'        CStr(recordKey), "Submitted At"))
'
'    If Len(submittedAt) > 0 Then
'
'        submittedDate = 0
'
'        If mid$(submittedAt, 5, 1) = "-" And _
'           mid$(submittedAt, 8, 1) = "-" Then
'
'            ' ISO format: 2026-10-16T17:35:40Z
'            submittedDate = DateSerial( _
'                CInt(Left$(submittedAt, 4)), _
'                CInt(mid$(submittedAt, 6, 2)), _
'                CInt(mid$(submittedAt, 9, 2)))
'
'        ElseIf IsDate(submittedAt) Then
'
'            ' Standard format: 10/29/2026 12:41
'            submittedDate = DateValue(CDate(submittedAt))
'
'        End If
'
'        If submittedDate > 0 Then
'            If submittedDate < DateAdd("d", -7, Date) Then
'                agingMatches = agingMatches + 1
'            End If
'        End If
'
'    End If
'
'Next recordKey
'
'    Debug.Print "--------------------------"
'    Debug.Print "Z Number: " & zNum
'    Debug.Print "Defect Count: " & matches.Count
'    Debug.Print "Aging Defect Count: " & agingMatches
'    Debug.Print "--------------------------"
'
'End Sub

'---------------------------------------------------------------------------------------------------------------

Private Sub DebugDefectTally()

    Dim csv As CSVEngine
    Dim matches As Collection
    Dim defectCount As Long
    Dim agingMatches As Long
    Dim recordKey As Variant
    Dim submittedAt As String
    Dim submittedDate As Date
    Dim resolved As String
    Dim zNum As String
Dim resolvedCount As Long
    zNum = Trim$(Me.txtZNumber.Value)

    If Len(zNum) = 0 Then Exit Sub

    Set csv = New CSVEngine

    If Not csv.LoadFromFile(DB_PATH, "Submission ID") Then
        Debug.Print "Failed to load defect CSV."
        Exit Sub
    End If

    Set matches = csv.FindExact("Z Number", zNum)

defectCount = 0
agingMatches = 0
resolvedCount = 0

    For Each recordKey In matches

        ' Check resolved status first
        resolved = Trim$(csv.GetField( _
            CStr(recordKey), "Resolved"))

        ' Skip resolved defects
If StrComp(resolved, "Yes", vbTextCompare) = 0 Then

    resolvedCount = resolvedCount + 1

Else
            ' Count only unresolved defects
            defectCount = defectCount + 1

            submittedAt = Trim$(csv.GetField( _
                CStr(recordKey), "Submitted At"))

            If Len(submittedAt) > 0 Then

                submittedDate = 0

                If mid$(submittedAt, 5, 1) = "-" And _
                   mid$(submittedAt, 8, 1) = "-" Then

                    ' ISO format
                    submittedDate = DateSerial( _
                        CInt(Left$(submittedAt, 4)), _
                        CInt(mid$(submittedAt, 6, 2)), _
                        CInt(mid$(submittedAt, 9, 2)))

                ElseIf IsDate(submittedAt) Then

                    ' Standard date/time format
                    submittedDate = DateValue(CDate(submittedAt))

                End If

                If submittedDate > 0 Then
                    If submittedDate < DateAdd("d", -7, Date) Then
                        agingMatches = agingMatches + 1
                    End If
                End If

            End If

        End If

    Next recordKey

Debug.Print "--------------------------"
Debug.Print "Z Number: " & zNum
Debug.Print "Total Defects: " & matches.Count
Debug.Print "Open Defects: " & defectCount
Debug.Print "Aging Defects: " & agingMatches
Debug.Print "Resolved Defects: " & resolvedCount
Debug.Print "--------------------------"

End Sub


