Attribute VB_Name = "modHTML"
Option Explicit
Function ColorText(text As String, colorCode As String) As String
    ' ANSI Color Constants for ColorText function used in vba created .bat files
    ' Standard colors                                Bright colors                                           Optional Text Effects
    ' ANSI_Black  = 30                            ANSI_BrightBlack  = 90                            ANSI_Reset   = "0"
    ' ANSI_Red  = 31                              ANSI_BrightRed  = 91                              ANSI_Bold   = "1"
    ' ANSI_Green  = 32                          ANSI_BrightGreen  = 92                          ANSI_Dim   = "2"
    ' ANSI_Yellow  = 33                         ANSI_BrightYellow  = 93                         ANSI_Underline   = "4"
    ' ANSI_Blue  = 34                             ANSI_BrightBlue  = 94                             ANSI_Blink   = "5"
    ' ANSI_Magenta  = 35                    ANSI_BrightMagenta  = 95                    ANSI_Invert   = "7"
    ' ANSI_Cyan  = 36                           ANSI_BrightCyan  = 96                           ANSI_Hidden   = "8"
    ' ANSI_White  = 37                         ANSI_BrightWhite  = 97
    
    ' Separate chained values with a semicolon
    ' Calling the function examples if batchCode is the variable name
            ' Single color
                    'batchCode = batchCode & "echo " & ColorText("Hello", 32)  & vbCrLf                                                                                     Green text
        
            ' Bold bright color
                    'batchCode = batchCode & "echo " & ColorText("Connecting to secure data node...", "1;91") & vbCrLf                               Bold bright red


    Dim ESC As String
    ESC = Chr(27)
    ColorText = ESC & "[" & colorCode & "m" & text & ESC & "[0m"
End Function
'Public teamVersion As String
'****************************************************************************************************************
'**************************************        HTML Stuff         ***********************************************
Sub CheckHtmlPage()
    On Error GoTo ErrorHandler

    Dim fso As Object, fileStream As Object, htmlDoc As Object
    Dim htmlContent As String, updateStatus As String, newestVersion As String
    Dim url As String, version As String

    version = the_version
    Debug.Print "Current Version: ", version

    url = HTMLFILEPATH

    Set fso = CreateObject("Scripting.FileSystemObject")

    If Not fso.fileExists(url) Then
        Debug.Print "File not found: " & url
        GoTo CleanUp
    End If

    Set fileStream = fso.OpenTextFile(url, 1)
    htmlContent = fileStream.ReadAll
    fileStream.Close
    Set fileStream = Nothing

    Set htmlDoc = CreateObject("HTMLFile")
    htmlDoc.body.innerHTML = htmlContent

    If Not htmlDoc.getElementByID("teamVersion") Is Nothing Then
        newestVersion = htmlDoc.getElementByID("teamVersion").innerText
    End If

    Debug.Print "Html page version:", newestVersion

    If Not htmlDoc.getElementByID("updateStatus Always On") Is Nothing Then
        updateStatus = htmlDoc.getElementByID("updateStatus Always On").innerText
    End If

    Debug.Print "update Status:", updateStatus

CleanUp:
    On Error Resume Next
    If Not fileStream Is Nothing Then fileStream.Close
    Set fileStream = Nothing
    Set htmlDoc = Nothing
    Set fso = Nothing
    If newestVersion <> version Then
        Debug.Print "calling update"
        Dim response As VbMsgBoxResult
        response = MsgBox("An update is detected!" & vbNewLine & vbNewLine & _
               "The tool will close momentarily and re-open after it is updated.", _
               vbOKOnly, "Update Available")
'        If response = vbYes Then
            Call UpdateTool
'        Else
'            Debug.Print "User declined update"
'        End If
    End If
    Exit Sub

ErrorHandler:
    Debug.Print "An error occurred: " & Err.Description
    Resume CleanUp
End Sub


    Sub UpdateTool()
    Dim fso As Object
    Dim Shell As Object
    Dim batchFilePath As String
    Dim batchFile As Integer
    Dim batchCode As String
 '   Dim oldFilePath As String
    Exit Sub
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set Shell = CreateObject("WScript.Shell")
    batchFilePath = Environ("TEMP") & "\tracker_update.bat"


    ' Build batch code
    batchCode = "@echo off" & vbCrLf
    batchCode = batchCode & "title Executing AuditFormTool Update..." & vbCrLf
    batchCode = batchCode & "mode con: cols=140 lines=35" & vbCrLf
    batchCode = batchCode & "echo " & ColorText("      = = = = = = = = = = = = = = = = = = = = = = =  = = = =  = = = = = = = = = = = = = = = = = = = = = = = = = = = = =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("    =                                                 ddddddd                                                          =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   = UUUUUUU     UUUUUUU                              d:::::d                         ttt                              =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   = U:::::U     U:::::U                              d:::::d                      ttt::t                              =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   = U:::::U     U:::::U                              d:::::d                      t::::t                              =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   = UU::::U     U::::UU                              d::::d                       t::::t                              =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =  U::::U     U::::U pppp   pppppppp        dddddddd::::d    aaaaaaaaaaa   tttttt::::ttttttt        eeeeeeeeeee     =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =  U::::D     D::::U p:::ppp::::::::p     dd::::::::::::d    a::::::::::a  t:::::::::::::::t      ee:::::::::::ee   =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =  U::::D     D::::U p:::::::::::::::p   d::::::::::::::d    aaaaaaaa::::a t:::::::::::::::t     e:::::eeeee:::::ee =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =  U::::D     D::::U pp:::::ppppp:::::p d::::::ddddd::::d            a:::a ttttt::::::tttttt    e:::::e     e:::::e =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =  U::::D     D::::U  p::::p     p::::p d:::::d    d::::d      aaaaaa::::a      t::::t          e::::::eeeee::::::e =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =  U::::D     D::::U  p::::p     p::::p d::::d     d::::d    aa::::::::::a      t::::t          e::::::::::::::::e  =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =  U::::D     D::::U  p::::p     p::::p d::::d     d::::d   a:::aaaa:::::a      t::::t          e:::::eeeeeeeeeee   =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =  U:::::U   U:::::U  p::::p    p:::::p d::::d     d::::d  a:::a    a::::a      t::::t    ttttt e::::::e            =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =  U::::::UUU::::::U  p::::ppppp::::::p d:::::ddddd:::::dd a:::a    a::::a      t:::::tttt::::t e:::::::e           =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =   UU:::::::::::UU   p::::::::::::::p   d:::::::::::::::d a::::aaaa:::::a      tt::::::::::::t  e:::::::eeeeeeee   =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =     UU:::::::UU     p::::::::::::pp     d::::::::ddd:::d  a:::::::::aa::a       tt:::::::::tt   ee::::::::::::e   =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =       UUUUUUU       p:::::ppppppp        dddddddd   dddd   aaaaaaaaa  aaa         ttttttttt       eeeeeeeeeeeee   =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =                     p::::p                                                                                        =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =                     p::::p                                                                                        =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =                    p::::::p                                                                                       =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =                    p::::::p                                                                                       =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("   =                    p::::::p                                                                                       =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("    =                   pppppppp                                                                                      =", "1;96") & vbCrLf
    batchCode = batchCode & "echo " & ColorText("      = = = = = = = = = = = = = = = = =  = = = =  = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = ", "1;96") & vbCrLf
    batchCode = batchCode & "echo." & vbCrLf
    batchCode = batchCode & "echo Waiting for Paintbrush to close..." & vbCrLf
    batchCode = batchCode & "del /F /Q ""%USERPROFILE%\Documents\Defect Tracker\Defect_Tracker_Team_Member.xlsm""" & vbCrLf
    batchCode = batchCode & "timeout /t 1 >nul" & vbCrLf
    batchCode = batchCode & "copy /Y ""J:\zz_Access_Tools_Data\Developers\Versions\Defect Tracking\Defect_Tracker_Team_Member.xlsm"" ""%USERPROFILE%\Documents\Defect Tracker\Defect_Tracker_Team_Member.xlsm""" & vbCrLf
    batchCode = batchCode & "timeout /t 2 >nul" & vbCrLf
    batchCode = batchCode & "powershell -command ""Unblock-File -Path '%USERPROFILE%\Documents\Defect Tracker\Defect_Tracker_Team_Member.xlsm'""" & vbCrLf
    batchCode = batchCode & "start excel ""%USERPROFILE%\Documents\Defect Tracker\Defect_Tracker_Team_Member.xlsm""" & vbCrLf
    batchCode = batchCode & "del ""%~f0""" & vbCrLf

    ' Write the batch file
    batchFile = FreeFile
    Open batchFilePath For Output As #batchFile
    Print #batchFile, batchCode
    Close #batchFile
    
    Shell.Run """" & batchFilePath & """", vbNormalFocus, False

    ThisWorkbook.Close False

End Sub

' Simple sleep helper since VBA has no native Sleep without a Win32 declare
Private Sub Sleep_(ms As Long)
    Dim t As Single
    t = Timer
    Do While Timer < t + (ms / 1000)
        DoEvents
    Loop
End Sub




