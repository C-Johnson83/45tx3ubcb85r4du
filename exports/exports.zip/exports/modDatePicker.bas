Attribute VB_Name = "modDatePicker"
Option Explicit

Public Function PickDate( _
    Optional ByVal StartingDate As Variant) As Variant

    Dim frm As frmDatePicker
    Dim startValue As Date

    If IsDate(StartingDate) Then
        startValue = CDate(StartingDate)
    Else
        startValue = Date
    End If
    
    Set frm = New frmDatePicker

    
    frm.InitializeCalendar startValue
    frm.Show vbModal

    If frm.Cancelled Then
        PickDate = Empty
    Else
        PickDate = frm.SelectedDate
    End If

    Unload frm
    Set frm = Nothing

End Function

