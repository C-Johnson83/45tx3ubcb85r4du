Attribute VB_Name = "modEmailer"
Option Explicit




Public Function BuildDefectEmail( _
    ByVal eVar1 As String, _
    ByVal eVar2 As String, _
    ByVal eVar3 As String, _
    ByVal eVar4 As String, _
    ByVal eVar5 As String, _
    ByVal eVar6 As String, _
    ByVal eVar7 As String, _
    ByVal eVar8 As String, _
    ByVal eVar9 As String) As String
    
    Debug.Print "Value: [" & eVar6 & "]"
Debug.Print "Type: " & TypeName(eVar6)
Debug.Print "Length: " & Len(eVar6)
Debug.Print "IsNumeric: " & IsNumeric(eVar6)
    
    Dim HTML As String
    Dim ImpactColor As String
    Dim ImpactLabel As String
    Dim ImpactValue As Double

    'Determine impact styling
    If Not IsNumeric(eVar6) Then
        Err.Raise vbObjectError + 1000, _
                  "BuildDefectEmail", "Invalid impact value."
    End If

    MsgBox eVar6
    ImpactValue = CDbl(eVar6)

    Select Case ImpactValue

        Case Is > 40
            ImpactColor = "#CC0000"
            ImpactLabel = "HIGH"

        Case Is > 20
            ImpactColor = "#E68A00"
            ImpactLabel = "MEDIUM"

        Case Else
            ImpactColor = "#218838"
            ImpactLabel = "LOW"

    End Select

    'Encode values for HTML
    eVar1 = HtmlEncode(eVar1)
    eVar2 = HtmlEncode(eVar2)
    eVar3 = HtmlEncode(eVar3)
    eVar4 = HtmlEncode(eVar4)
    eVar5 = HtmlEncode(eVar5)
    eVar6 = HtmlEncode(eVar6)
    eVar7 = HtmlEncode(eVar7)
    eVar8 = HtmlEncode(eVar8)

    eVar9 = HtmlEncode(eVar9)
    eVar9 = Replace(eVar9, vbCrLf, "<br>")
    eVar9 = Replace(eVar9, vbCr, "<br>")
    eVar9 = Replace(eVar9, vbLf, "<br>")

    'Start HTML document
    HTML = "<html><body style='margin:0;padding:20px;" & _
           "background-color:#F2F2F2;font-family:Arial,sans-serif;'>"

    'Main email container
    HTML = HTML & _
        "<table width='650' align='center' cellpadding='0' " & _
        "cellspacing='0' style='background-color:#FFFFFF;" & _
        "border:1px solid #DDDDDD;'>"

    'Target-inspired header
    HTML = HTML & _
        "<tr><td style='background-color:#CC0000;" & _
        "padding:22px 25px;color:#FFFFFF;'>" & _
        "<div style='font-size:22px;font-weight:bold;'>" & _
        "DEFECT ENTRY NOTIFICATION</div>" & _
        "<div style='font-size:13px;padding-top:6px;'>" & _
        eVar1 & " | INBOUND | ICQA</div>" & _
        "</td></tr>"

    'Main content
    HTML = HTML & _
        "<tr><td style='padding:25px;color:#333333;" & _
        "font-size:14px;line-height:1.6;'>"

    'Greeting
    HTML = HTML & _
        "<p>Hello " & eVar1 & " senior,</p>" & _
        "<p>There was a defect entry added for " & _
        "<b>" & eVar2 & "</b> which occurred on " & _
        "<b>" & eVar3 & "</b>.</p>"

    'Follow-up instructions
    HTML = HTML & _
        "<table width='100%' cellpadding='12' cellspacing='0' " & _
        "style='background-color:#F5F5F5;" & _
        "border-left:4px solid #CC0000;'>" & _
        "<tr><td style='font-size:14px;line-height:1.6;'>" & _
        "<b>FOLLOW-UP REQUIRED</b><br><br>" & _
        "Please ensure follow-up is completed by the " & _
        "<b>" & eVar4 & "</b> and a note is added in Workday.<br>" & _
        "Once verified, please complete in the Defect Tracker.<br>" & _
        "This TM has had <b>" & eVar5 & _
        "</b> defect occurrences." & _
        "</td></tr></table>"

    'Defect details heading
    HTML = HTML & _
        "<h3 style='color:#CC0000;margin-top:30px;" & _
        "margin-bottom:12px;'>DEFECT DETAILS</h3>"

    'Details table
    HTML = HTML & _
        "<table width='100%' cellpadding='10' cellspacing='0' " & _
        "style='border-collapse:collapse;font-size:14px;'>"

    'Impact row
    HTML = HTML & _
        "<tr style='background-color:#F5F5F5;'>" & _
        "<td width='35%'><b>Defect Impact</b></td>" & _
        "<td><span style='color:" & ImpactColor & _
        ";font-weight:bold;'>" & eVar6 & _
        " - " & ImpactLabel & "</span></td></tr>"

    'Defect type
    HTML = HTML & _
        "<tr><td><b>Defect Type</b></td>" & _
        "<td>" & eVar7 & "</td></tr>"

    'Defect subtype
    HTML = HTML & _
        "<tr style='background-color:#F5F5F5;'>" & _
        "<td><b>Defect Sub-Type</b></td>" & _
        "<td>" & eVar8 & "</td></tr>"

    HTML = HTML & "</table>"

    'Description section
    HTML = HTML & _
        "<h4 style='margin-top:25px;margin-bottom:8px;'>" & _
        "Defect Description</h4>" & _
        "<div style='background-color:#F8F8F8;" & _
        "border:1px solid #E0E0E0;padding:15px;" & _
        "line-height:1.6;'>" & eVar9 & "</div>"

    'Signature
    HTML = HTML & _
        "<p style='margin-top:30px;'>Thank you,<br>" & _
        "<b>ICQA</b></p>"

    HTML = HTML & "</td></tr>"

    'Footer
    HTML = HTML & _
        "<tr><td style='background-color:#333333;" & _
        "padding:18px;text-align:center;color:#FFFFFF;'>" & _
        "<div style='font-size:13px;font-weight:bold;'>" & _
        "TARGET | ICQA</div>" & _
        "<div style='font-size:11px;color:#CCCCCC;" & _
        "margin-top:8px;'>" & _
        "This message was automatically generated." & _
        "</div></td></tr>"

    'Close document
    HTML = HTML & "</table></body></html>"

    BuildDefectEmail = HTML

End Function

Public Function HtmlEncode(ByVal Value As String) As String

    Value = Replace(Value, "&", "&amp;")
    Value = Replace(Value, "<", "&lt;")
    Value = Replace(Value, ">", "&gt;")
    Value = Replace(Value, """", "&quot;")
    Value = Replace(Value, "'", "&#39;")

    HtmlEncode = Value

End Function




Public Function SendNotification(ByVal Impact As String, _
                                 ByVal tmKey As String, _
                                 ByVal EmailSubject As String, _
                                 ByVal EmailBody As String) As Boolean

    Dim OutlookApp As Object
    Dim OutlookMail As Object

    Dim GroupLow As String
    Dim GroupMedium As String
    Dim GroupHigh As String

    Dim Recipients As String
    Dim ImpactValue As Double

    'Validate impact
    If Not IsNumeric(Impact) Then
        MsgBox "Invalid impact value.", vbExclamation
        Exit Function
    End If

    ImpactValue = CDbl(Impact)

    'Determine email groups based on TM Key
Select Case UCase(Trim(tmKey))

    Case "B1"
        GroupLow = "christopher.johnson7@target.com"
        GroupMedium = "christopher.johnson7@target.com"
        GroupHigh = "christopher.johnson7@target.com"

    Case "B2"
        GroupLow = "christopher.johnson7@target.com"
        GroupMedium = "christopher.johnson7@target.com"
        GroupHigh = "christopher.johnson7@target.com"

    Case "B3"
        GroupLow = "christopher.johnson7@target.com"
        GroupMedium = "christopher.johnson7@target.com"
        GroupHigh = "christopher.johnson7@target.com"

    Case "B4"
        GroupLow = "christopher.johnson7@target.com"
        GroupMedium = "christopher.johnson7@target.com"
        GroupHigh = "christopher.johnson7@target.com"

    Case Else
        MsgBox "Invalid TM Key.", vbExclamation
        Exit Function

End Select

'Determine recipients based on impact
Select Case ImpactValue

    Case Is > 40
        Recipients = GroupHigh

    Case Is > 20
        Recipients = GroupMedium

    Case Else
        Recipients = GroupLow

End Select

    On Error GoTo ErrorHandler

    'Connect to Outlook
    Set OutlookApp = CreateObject("Outlook.Application")
    Set OutlookMail = OutlookApp.CreateItem(0)

    'Build and send email
    With OutlookMail
        .To = Recipients
        .Subject = EmailSubject
        .HTMLBody = EmailBody
 '       .Send
        .Display
    End With

    SendNotification = True

CleanUp:
    Set OutlookMail = Nothing
    Set OutlookApp = Nothing
    Exit Function

ErrorHandler:
    MsgBox "Email could not be submitted: " & Err.Description, vbCritical
    SendNotification = False
    Resume CleanUp

End Function

