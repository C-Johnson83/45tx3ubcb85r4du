Attribute VB_Name = "modShow"
Option Explicit
Sub ShowSubmissions()
frmDefectForm.Show vbModeless
End Sub

