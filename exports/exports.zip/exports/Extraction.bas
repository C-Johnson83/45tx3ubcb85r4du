Attribute VB_Name = "Extraction"
Option Explicit

' ==========================================
' MACRO 1: EXPORT FROM THE ACTIVE WORKBOOK
' ==========================================
Sub ExportActiveWorkbookVBA()
    Dim fd As FileDialog
    Dim targetFolder As String
    Dim vbComp As Object
    Dim fileName As String
    Dim ext As String
    Dim targetWB As Workbook
    
    ' Let user choose: Active workbook or PERSONAL.XLSB
    Dim choice As Integer
    choice = MsgBox("Click YES to export PERSONAL.XLSB" & vbCrLf & "Click NO to export the Active Workbook", vbYesNoCancel, "Which Workbook?")
    
    If choice = vbCancel Then Exit Sub
    
    If choice = vbYes Then
        On Error Resume Next
        Set targetWB = Workbooks("PERSONAL.XLSB")
        On Error GoTo 0
        If targetWB Is Nothing Then
            MsgBox "PERSONAL.XLSB is not open or was not found.", vbExclamation
            Exit Sub
        End If
    Else
        Set targetWB = ActiveWorkbook
        If targetWB.name = "PERSONAL.XLSB" Then
            MsgBox "PERSONAL.XLSB is hidden and cannot be the active workbook. Run again and choose YES.", vbExclamation
            Exit Sub
        End If
    End If
    
    ' Folder picker
    Set fd = Application.FileDialog(msoFileDialogFolderPicker)
    With fd
        .Title = "Select Target Folder for VBA Export"
        .AllowMultiSelect = False
        If .Show = -1 Then
            targetFolder = .SelectedItems(1) & "\"
        Else
            MsgBox "Export cancelled.", vbInformation
            Exit Sub
        End If
    End With
    
    For Each vbComp In targetWB.VBProject.VBComponents
        Select Case vbComp.Type
            Case 1: ext = ".bas"
            Case 2: ext = ".cls"
            Case 3: ext = ".frm"
            Case Else: ext = ""
        End Select
        
        If ext <> "" Then
            fileName = targetFolder & vbComp.name & ext
            vbComp.Export fileName
        End If
    Next vbComp
    
    MsgBox "Successfully exported components from: " & targetWB.name, vbInformation, "Export Complete"
End Sub

' ==========================================
' MACRO 2: IMPORT INTO THE ACTIVE WORKBOOK
' ==========================================
Sub ImportActiveWorkbookVBA()
    Dim fd As FileDialog
    Dim targetFolder As String
    Dim fso As Object
    Dim folderObj As Object
    Dim fileObj As Object
    Dim ext As String
    Dim compName As String
    Dim existingComp As Object
    Dim targetWB As Workbook
    
    Set targetWB = ActiveWorkbook
    
    ' Safety Check: Prevent users from importing into the tool itself
    If targetWB.name = ThisWorkbook.name Then
        MsgBox "Please click into the workbook you want to import into BEFORE running this macro.", vbExclamation, "Wrong Workbook Active"
        Exit Sub
    End If
    
    ' Set up the Folder Picker
    Set fd = Application.FileDialog(msoFileDialogFolderPicker)
    With fd
        .Title = "Select Folder Containing VBA Files to Import"
        .AllowMultiSelect = False
        If .Show = -1 Then
            targetFolder = .SelectedItems(1) & "\"
        Else
            MsgBox "Import cancelled.", vbInformation
            Exit Sub
        End If
    End With
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set folderObj = fso.GetFolder(targetFolder)
    
    Application.ScreenUpdating = False
    
    For Each fileObj In folderObj.Files
        ext = LCase(fso.GetExtensionName(fileObj.name))
        
        If ext = "bas" Or ext = "cls" Or ext = "frm" Then
            compName = fso.GetBaseName(fileObj.name)
            
            Set existingComp = Nothing
            On Error Resume Next
            Set existingComp = targetWB.VBProject.VBComponents(compName)
            On Error GoTo 0
            
            If Not existingComp Is Nothing Then
                If existingComp.Type Mod 100 <> 0 Then
                    targetWB.VBProject.VBComponents.Remove existingComp
                End If
            End If
            
            targetWB.VBProject.VBComponents.Import fileObj.path
        End If
    Next fileObj
    
    Application.ScreenUpdating = True
    MsgBox "Successfully imported and replaced components in: " & targetWB.name, vbInformation, "Import Complete"
End Sub
